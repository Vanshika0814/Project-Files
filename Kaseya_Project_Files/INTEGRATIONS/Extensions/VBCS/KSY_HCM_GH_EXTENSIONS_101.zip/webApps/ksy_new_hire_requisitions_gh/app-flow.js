define(['oj-sp/spectra-shell/config/config'], function() {
  'use strict';

  class AppModule {
  }

  AppModule.prototype.getHiringManagerRoleId = function (userRolesArr, roleName) {
    //search field object
    if(!userRolesArr ||  userRolesArr.length === 0){
      return null;
    }
    const item = userRolesArr.find(role => role.name === roleName && role.type === "job_admin" );
    return item?.id;
  };
  
  return AppModule;
});
