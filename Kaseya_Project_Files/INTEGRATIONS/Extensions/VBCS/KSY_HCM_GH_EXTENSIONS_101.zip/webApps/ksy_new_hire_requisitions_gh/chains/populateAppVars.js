define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class populateAppVars extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $application, $constants, $variables, $functions } = context;

      //Get Hiring manager role id

      const getGHRolesCall = await Actions.callRest(context, {
        endpoint: 'getall_userRoles_gh/get',
      });

      const roleId = await $functions.getHiringManagerRoleId(getGHRolesCall?.body, $constants.hiringManRoleName);

      $variables.ghHiringManRoleId = roleId;

      console.log("role_id " + $variables.ghHiringManRoleId);


    }
  }

  return populateAppVars;
});
