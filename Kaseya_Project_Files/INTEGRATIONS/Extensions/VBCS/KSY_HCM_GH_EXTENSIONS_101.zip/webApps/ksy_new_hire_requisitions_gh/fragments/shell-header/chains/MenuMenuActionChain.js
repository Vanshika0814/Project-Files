define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class MenuMenuActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.menuId 
     */
    async run(context, { menuId }) {
      const { $fragment, $application, $constants, $variables } = context;

      switch (menuId) {
        case "signout":
          await Actions.logout(context, {
          });
          break;
         
        case "gotohcm": await Actions.openUrl(context, {
          url: $application.constants.fusionURL + "/fscmUI/faces/FuseWelcome",


        });
        case undefined:
          break;
      }


    }
  }

  return MenuMenuActionChain;
});
