define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getall_locationsLovFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if (configuration.hookHandler.context.fetchOptions.filterCriterion) {
        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_locations/getall_locations',
          responseType: 'getallLocationsLovResponse',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
          uriParams: {
            q: "EmployeeLocationFlag=true and ActiveStatus='A' and (upper(LocationName) like '%" + configuration.hookHandler.context.fetchOptions.filterCriterion.text.toUpperCase() + "%')",
            orderBy: "LocationName",
          },
        });

        return callRestEndpoint1;
      }
      else {
        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_locations/getall_locations',
          responseType: 'getallLocationsLovResponse',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
          uriParams: {
            orderBy: "LocationName",
          },
          requestTransformOptions: {
            filter:
            {
              "op": "$and",
              criteria: [
                {
                  op: "$eq",
                  attribute: "ActiveStatus",
                  value: 'A',
                },
                {
                  op: "$eq",
                  attribute: "EmployeeLocationFlag",
                  value: true,
                },
              ]
            }
          }
        });

        return callRestEndpoint1;
      }
    }
  }

  return getall_locationsLovFetch;
});
