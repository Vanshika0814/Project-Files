define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateXxreqJobReqRequestsChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainCreateXxreqJobReqRequestsResult = await Actions.navigateToPage(context, {
        page: 'main-create-req-ux',
      });
    }
  }

  return navigateToCreateXxreqJobReqRequestsChain;
});
