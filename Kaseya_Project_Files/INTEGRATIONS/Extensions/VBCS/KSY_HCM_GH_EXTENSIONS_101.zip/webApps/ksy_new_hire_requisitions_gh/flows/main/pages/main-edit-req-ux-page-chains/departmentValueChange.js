define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class departmentValueChange extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables, $and, $eq } = context;

      //budgetHolderFirstLoadFlag is default to true: used to contorl first load an set initial fetched value properly
      if ($variables.budgetHolderFirstLoadFlag === false) {
        if (key !== null && key !== undefined) {

          $variables.areasOfResponsibilityListSDP.filterCriterion = {
            op: '$and',
            criteria: [
              {
                op: '$eq',
                attribute: 'DepartmentId',
                value: key,
              },
              {
                op: '$eq',
                attribute: 'ResponsibilityType',
                value: 'BUDGETER',
              },
            ],
          };

          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.selectedBudgetHolderData.data',
              '$page.variables.xxreqJobReqRequests.budgetHolderId',
            ],
          });
        }
      }

      //Set first load of budget holder to false to let object variable get a new item selection
      $variables.budgetHolderFirstLoadFlag = false;
    }
  }

  return departmentValueChange;
});
