define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getall_suites_valuesFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if (configuration.hookHandler.context.fetchOptions.filterCriterion) {

        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_valueSetsValues/getall_valueSets-values',
          uriParams: {
            'valueSets_Id': $application.constants.suiteValueSetCode,
            q: "EnabledFlag='Y' and (upper(Value) LIKE '%" + configuration.hookHandler.context.fetchOptions.filterCriterion.text.toUpperCase() + "%')",

          },
          responseType: 'getallSuitesResponse',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
        });

        return callRestEndpoint1;
      } else {
        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_valueSetsValues/getall_valueSets-values',
          uriParams: {
            'valueSets_Id': $application.constants.suiteValueSetCode,
          },
          responseType: 'getallSuitesResponse',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
          requestTransformOptions: {
            filter: {
              "op": "$eq",
              "attribute": "EnabledFlag",
              "value": "Y"
            }
          }
        });

        return callRestEndpoint1;

      }
    }
  }

  return getall_suites_valuesFetch;
});
