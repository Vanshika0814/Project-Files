define([], () => {
  'use strict';

  class PageModule {

    mergeAllRequestData(requests, jobTitles, departments, locations) {
      // validate request data
      if (!requests || requests.length === 0) {
        return [];
      }
      // Create job map
      const jobTitlesMap = new Map(
        jobTitles?.map(job => [job.JobId, job.JobName])
      );
      // Use 'OrganizationId' as key and 'Name' as value
      const departmentsMap = new Map(
        departments?.map(dept => [dept.OrganizationId, dept.Name])
      );
      // Use 'LocationId' as key and 'LocationName' as value.
      const locationsMap = new Map(
        locations?.map(loc => [loc.LocationId, loc.LocationName])
      );
      // 2. Map over request to create final result.
      return requests.map(request => {
        // 3. Search value for each.
        const jobName = jobTitlesMap.get(request.jobTitleId) || 'Job Title Not Found';
        const departmentName = departmentsMap.get(request.departmentId) || 'Department Not Found';
        const locationName = locationsMap.get(request.locationId) || 'Location Not Found';
        // 4. Return new requests object with new attributes
        return {
          ...request,
          JobName: jobName,
          DepartmentName: departmentName,
          LocationName: locationName
        };
      });
    }

  }



  /*PageModule.prototype.updatePropertySDP = function (mainSDP, lkupSDP, mainPropKey, lkupPropKey, mainToUpdatePropKey, lkupSourcePropKey) {

    console.log('hi');
    
    console.log(typeof mainSDP);

    let mainSDPString = JSON.stringify(mainSDP);
    console.log(typeof mainSDPString);
    let mainSDPArray = JSON.parse(mainSDP);
    console.log(typeof mainSDPArray);

    const updatedMainSDP = mainSDPArray.map((mainItem) => {
      const matchingUpdate = JSON.parse(JSON.stringify(lkupSDP)).find(
        (updateItem) => updateItem[lkupPropKey] === mainItem[mainPropKey]
      );

      if (matchingUpdate) {
        return { ...mainItem, [mainToUpdatePropKey]: matchingUpdate[lkupSourcePropKey] }; // Create a new object with updated status
      }
      return mainItem; // Return the original object if no match
    });

    return updatedMainSDP;

  };*/



  return PageModule;
});
