define([], () => {
  'use strict';

  class PageModule {
    filterLineManagers(allUsers) {
      // Etapa 1: Validar a entrada para evitar erros.
      if (!allUsers || !Array.isArray(allUsers)) {
        console.error("Entrada para filterLineManagers não é um array válido ou está vazia.");
        return []; // Retorna um array vazio se a entrada for inválida.
      }

      // Etapa 2: Usar a função 'filter' do JavaScript para criar um novo array com os resultados.
      return allUsers.filter(user => {
        // Verificação segura para garantir que user.userAccountRoles e user.userAccountRoles.items existam
        const roles = user.userAccountRoles && user.userAccountRoles.items;

        // Se o usuário não tiver um array de roles, pule para o próximo.
        if (!roles || !Array.isArray(roles)) {
          return false;
        }

        // Etapa 3: Usar 'some' para verificar eficientemente se alguma das roles corresponde.
        // Ele para assim que encontra uma correspondência.
        return roles.some(role => role && role.RoleCode === 'ORA_PER_LINE_MANAGER_ABSTRACT');
      });
    }

    buildWorkerQuery(managersArray) {
      if (!managersArray || managersArray.length === 0) {
        return ''; // Retorna vazio se não houver gerentes, para evitar chamadas de API desnecessárias.
      }

      // Extrai apenas os PersonId de cada gerente
      const personIds = managersArray.map(manager => manager.PersonId);

      // Constrói a string de consulta
      return `PersonId in (${personIds.join(',')})`;
    }

    mergeManagerData(managersArray, workersArray) {
      // 1. Validação: Se a lista de workers estiver vazia ou inválida,
      // simplesmente retorna a lista original de gerentes para evitar erros.
      if (!workersArray || !Array.isArray(workersArray) || workersArray.length === 0) {
        console.warn("mergeManagerData: A lista de detalhes dos workers está vazia. Retornando dados parciais.");
        // Adiciona um DisplayName de fallback para consistência da UI
        return managersArray.map(manager => ({ ...manager, DisplayName: manager.Username }));
      }

      // 2. Otimização (O Pulo do Gato): Cria um "Mapa" para busca rápida.
      // Em vez de procurar na lista de workers repetidamente, nós a organizamos em um
      // objeto onde a chave é o PersonId. Isso torna a busca quase instantânea.
      const workerDetailsMap = new Map(
        workersArray.map(worker => [worker.PersonId, worker])
      );

      // 3. Mesclagem: Passa pela lista original de gerentes e cria a lista final.
      return managersArray.map(manager => {
        // Para cada gerente, busca seus detalhes no Mapa.
        const workerDetails = workerDetailsMap.get(manager.PersonId);

        // Retorna um novo objeto combinando as propriedades do gerente original
        // com o DisplayName encontrado.
        return {
          ...manager, // Copia todas as propriedades do gerente (PersonId, Username, etc.)
          
          // Adiciona o DisplayName. Se por acaso não encontrar detalhes, 
          // usa o Username como um valor reserva (fallback) para não mostrar "undefined".
          DisplayName: workerDetails ? workerDetails.DisplayName : manager.Username
        };
      });
    }
  }

  return PageModule;
});
