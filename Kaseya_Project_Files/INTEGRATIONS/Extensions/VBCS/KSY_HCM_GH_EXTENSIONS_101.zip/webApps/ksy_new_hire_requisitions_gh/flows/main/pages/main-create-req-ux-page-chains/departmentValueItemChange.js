define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class departmentValueItemChange extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {

      const { $page, $flow, $application, $constants, $variables, $eq, $and } = context;

      if (key !== null && key !== undefined) {

        $variables.areasOfResponsibilityListSDP.filterCriterion = {
          op: '$and',
          criteria: [
            {
              op: '$eq',
              attribute: 'DepartmentId',
              value: key,
            },
            {
              op: '$eq',
              attribute: 'ResponsibilityType',
              value: 'BUDGETER',
            },
          ],
        };

        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.selectedBudgetHolderData.data',
            '$page.variables.xxreqJobReqRequests.budgetHolderId',
          ],
        });

      }
    }
  }

  return departmentValueItemChange;
});
