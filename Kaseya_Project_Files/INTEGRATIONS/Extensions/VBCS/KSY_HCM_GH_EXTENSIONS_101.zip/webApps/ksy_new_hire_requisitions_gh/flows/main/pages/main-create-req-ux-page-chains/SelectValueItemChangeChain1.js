define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueItemChangeChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any} params.key
     * @param {any} params.data
     * @param {any} params.metadata
     * @param {any} params.valueItem
     */
    async run(context, { event, previousValue, value, updatedFrom, key, data, metadata, valueItem }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      //GET Conversion rate from today
      const today = new Date().toISOString().split('T')[0];
      const responseConversion = await Actions.callRest(context, {
        endpoint: 'getConversionRates/getall_currencyRates',
        uriParams: {
          onlyData: true,
          finder: 'CurrencyRatesFinder;fromCurrency=USD,toCurrency=' + $page.variables.xxreqJobReqRequests.currency + ',userConversionType=Corporate,startDate=' + today + ',endDate=' + today,
        },
      });
      $page.variables.xxreqJobReqRequests.conversionRate = responseConversion.body.items[0].ConversionRate;

      if ($page.variables.xxreqJobReqRequests.salaryBase != null || $page.variables.xxreqJobReqRequests.salaryBase !== undefined){
        const base = Number($page.variables.xxreqJobReqRequests.salaryBase) || 0;
        const rate = Number($page.variables.xxreqJobReqRequests.conversionRate) || 0;
        $page.variables.xxreqJobReqRequests.salaryBaseLocal = base * rate;
      }
      
      if ($page.variables.xxreqJobReqRequests.variableSalary != null || $page.variables.xxreqJobReqRequests.variableSalary !== undefined){
        const base = Number($page.variables.xxreqJobReqRequests.variableSalary) || 0;
        const rate = Number($page.variables.xxreqJobReqRequests.conversionRate) || 0;
        $page.variables.xxreqJobReqRequests.variableSalaryLocal = base * rate;
      }

    }
  }

  return SelectValueItemChangeChain1;
});
