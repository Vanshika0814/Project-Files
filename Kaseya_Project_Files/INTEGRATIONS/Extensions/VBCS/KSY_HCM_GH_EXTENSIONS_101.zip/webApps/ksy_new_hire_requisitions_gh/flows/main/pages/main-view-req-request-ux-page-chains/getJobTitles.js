define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getJobTitles extends ActionChain {

    /**
     * Iterates HCM GET Job titles rest api. Stores result in the  jobTitlesArray variable
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.offSetParam 
     * @param {number} params.limitParam 
     * @param {object[]} params.accumulator
     */
    async run(context, { offSetParam = 0, limitParam = 500, accumulator = []
    }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const jobTitlesResponse = await Actions.callRest(context, {
        endpoint: 'getall_jobTitles/getall_jobsLov',
        uriParams: {
          onlyData: true,
          fields: 'JobId,JobName,JobCode',
          limit: limitParam,
          offset: offSetParam
        },
        responseType: 'getall_jobsLov',
      }, { id: 'callRestJobTiltesHCM' });

      $variables.jobTitlesArray = [];
      $variables.jobTitlesArray.push(...accumulator);

      if (jobTitlesResponse.body?.items?.length > 0) {

        $variables.jobTitlesArray.push(...jobTitlesResponse.body.items);

        if (jobTitlesResponse.body?.hasMore === true) {

          //calls this same action chain
          const chainInternal = await Actions.callChain(context, {
            chain: 'getJobTitles',
            params: {
              limit: limitParam,
              offSetParam: limitParam + offSetParam,
              accumulator: $variables.jobTitlesArray,
            },
          });
        }
      }
    }
  }
  return getJobTitles;
});
