define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditXxreqJobReqRequestsChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.xxreqJobReqRequestsId
     */
    async run(context, { xxreqJobReqRequestsId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditReqRequestsResult = await Actions.navigateToPage(context, {
        page: 'main-edit-req-request',
        params: {
          xxreqJobReqRequestsId: xxreqJobReqRequestsId,
        },
      });
    }
  }

  return navigateToEditXxreqJobReqRequestsChain;
});
