define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class greenhouseCustomFieldValidation extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'getall_custom_fields_gh/get',
      });


      //      const divi = await $functions.validateGHFieldValue(response, "division", $variables.selectedDivisionData.data.Value);
      const divi = await $functions.validateGHFieldValue(response, "division", "NN");

      console.log("div_validation: " + divi);

      return divi;

    }
  }

  return greenhouseCustomFieldValidation;
});
