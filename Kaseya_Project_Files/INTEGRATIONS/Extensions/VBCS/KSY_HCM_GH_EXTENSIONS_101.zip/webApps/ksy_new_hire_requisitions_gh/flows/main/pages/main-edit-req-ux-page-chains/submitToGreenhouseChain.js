define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class submitToGreenhouseChain extends ActionChain {

    /**
    * @param {Object} context
    * @param {Object} params
    * @param {number} params.savedRequestId 
    */
    async run(context, { savedRequestId }) {
      const { $page, $flow, $application, $constants, $variables, $get } = context;

      if (savedRequestId !== null && savedRequestId !== undefined) {

        //Get req id generated in database
        const jobRequestsResponse = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_XxreqJobReqRequests',
          uriParams: {
            fields: "ghRequisitionName",
            onlyData: 'true',
            q: "requestId=" + savedRequestId,
          },
        });


        if (jobRequestsResponse.body.items[0].ghRequisitionName !== null && jobRequestsResponse.body.items[0].ghRequisitionName !== undefined) {

          let ghRequisitionId = jobRequestsResponse.body.items[0].ghRequisitionName;

          //console.log("reqId:" + ghRequisitionId);

          //emq - only for test delete later
          //$variables.xxreqJobReqRequests.ghRequisitionId = "20250731-2";

          $variables.jobPostHeader.template_job_id = $application.constants.templateJobId;
          $variables.jobPostHeader.number_of_openings = 1;
          $variables.jobPostHeader.job_name = $variables.selectedJobData.data.JobName + " - " + ghRequisitionId;
          $variables.jobPostHeader.external_department_id = $variables.xxreqJobReqRequests.departmentId;

          //test clear array
          $variables.jobPostHeader.external_office_ids = [];

          //$variables.jobPostHeader.external_office_ids.push($variables.xxreqJobReqRequests.locationId.toString());
          $variables.jobPostHeader.external_office_ids.push($variables.selectedLocationData.data.LocationCode);

          $variables.jobPostHeader.requisition_id = ghRequisitionId;
          //Post: Create job header in GH
          const jobPostResponse = await Actions.callRest(context, {
            endpoint: 'post_job_gh/post_job',
            headers: {
              'on-behalf-of': $application.constants.onBehalfOfId,
            },
            body: $variables.jobPostHeader,
          });

          //console.log("Response id " + jobPostResponse.body.id);
          console.log(jobPostResponse.errors);
          console.log(jobPostResponse.jobPostResponse);

           if (!jobPostResponse.ok) {
          // Create error message
          const errorMessage = jobPostResponse.body?.message  || `Could not create job in Greenhouse: status ${jobPostResponse.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

          /*
                console.log("1 " + $variables.jobPostHeader.template_job_id);
                console.log("2 " + $variables.jobPostHeader.number_of_openings);
                console.log("3 " + $variables.jobPostHeader.job_name);
                console.log("4 " + $variables.jobPostHeader.external_department_id);
                console.log("5 " + $variables.jobPostHeader.external_office_ids[0]);
                console.log("6 " + $variables.jobPostHeader.requisition_id);
          */

          //patch variables - add custom fields values
          if (jobPostResponse.body.id !== null && jobPostResponse.body.id !== undefined) {

            let jobRequestIdGH = jobPostResponse.body.id;

            //$get budgeter email;
            if ($variables.selectedBudgetHolderData.data.PersonId !== null && $variables.selectedBudgetHolderData.data.PersonId !== undefined) {
              const budgeterResponse = await Actions.callRest(context, {
                endpoint: 'getall_publicWorkers_emp/getall_publicWorkers',
                uriParams: {
                  onlyData: 'true',
                  fields: 'WorkEmail',
                  q: "PersonId=" + $variables.selectedBudgetHolderData.data.PersonId,
                },
              });

              if (budgeterResponse.body.items[0]?.WorkEmail !== null && budgeterResponse.body.items[0]?.WorkEmail !== undefined) {
                $variables.jobPatchFields.custom_fields.push({ "name_key": "budgeter", "value": budgeterResponse.body.items[0]?.WorkEmail });
              }
            }
            $variables.jobPatchFields.custom_fields.push({ "name_key": "job_type", "value": $variables.selectedRequestTypeData.data.ghRequestTypeId });
            if ($variables.xxreqJobReqRequests.reqTypeId === $application.constants.backFillTypeId ||
              $variables.xxreqJobReqRequests.reqTypeId === $application.constants.shadowTypeId) {

              $variables.jobPatchFields.custom_fields.push({ "name_key": "backfill_name", "value": $variables.selectedEmployeeData.data.DisplayName + " - " + $variables.selectedEmployeeData.data.PersonNumber });
              $variables.jobPatchFields.custom_fields.push({ "name_key": "termination_date", "value": $variables.xxreqJobReqRequests.exitDate });

            }
            $variables.jobPatchFields.custom_fields.push({
              "name_key": "manage_others", "value": ($variables.xxreqJobReqRequests.manageOthersFlag === null ||
                $variables.xxreqJobReqRequests.manageOthersFlag === undefined) ? "false" : $variables.xxreqJobReqRequests.manageOthersFlag
            });
            $variables.jobPatchFields.custom_fields.push({ "name_key": "job_code_job_1750947121.7309973", "value": $variables.selectedJobData.data.JobCode });
            $variables.jobPatchFields.custom_fields.push({ "name_key": "management_level", "value": $variables.selectedManagementLevelData.data.Meaning });

            if ($variables.xxreqJobReqRequests.rdOrSupportFlag === true) {
              $variables.jobPatchFields.custom_fields.push({ "name_key": "product", "value": $variables.selectedSuiteData.data.Value }); //suite
              $variables.jobPatchFields.custom_fields.push({ "name_key": "module", "value": $variables.selectedModuleData.data.Value });
            }
            $variables.jobPatchFields.custom_fields.push({ "name_key": "division", "value": $variables.selectedDivisionData.data.Value });
            $variables.jobPatchFields.custom_fields.push({
              "name_key": "salary_job_1641382351.3796115",
              "min_value": $variables.xxreqJobReqRequests.salaryBase,
              "max_value": $variables.xxreqJobReqRequests.salaryBase,
              "unit": "USD"
            });//salary
            $variables.jobPatchFields.custom_fields.push({
              "name_key": "salary",
              "min_value": $variables.xxreqJobReqRequests.variableSalary,
              "max_value": $variables.xxreqJobReqRequests.variableSalary,
              "unit": "USD"
              //variable salary
            });
            $variables.jobPatchFields.team_and_responsibilities = $variables.xxreqJobReqRequests.jobDesc;//description

            console.log("array test" + $variables.jobPatchFields.custom_fields[0]);

            const jobPatchResponse = await Actions.callRest(context, {
              endpoint: 'patch_job_gh/patch_job',
              uriParams: {
                jobId: jobRequestIdGH,
              },
              body: $variables.jobPatchFields,
              headers: {
                'on-behalf-of': $application.constants.onBehalfOfId,
              },
            });

            //reporting manager
            if ($variables.selectedManagerData.data.WorkEmail !== null && $variables.selectedManagerData.data.WorkEmail !== undefined) {

              const managerResponse = await Actions.callRest(context, {
                endpoint: 'getall_users_gh/getall_users_gh',
                uriParams: {
                  email: $variables.selectedManagerData.data.WorkEmail,
                },
              });

              if (managerResponse.body.id !== null && managerResponse.body.id !== undefined) {

                $variables.jobPostHiringManager.hiring_managers.push({ "user_id": managerResponse.body.id });


                await Actions.callRest(context, {
                  endpoint: 'post_job_hiring_team/post_job_hiring_team',
                  uriParams: {
                    jobId: jobRequestIdGH,
                  },
                  headers: {
                    'on-behalf-of': $application.constants.onBehalfOfId,
                  },
                  body: $variables.jobPostHiringManager,
                });


              }
            }
          }else{
            //Created job in GH not returning Id or error
          }
        } else {
          //Req ID not found
        }
      } else {
        //Action chain parameter null, id not returned after saving request or error
      }
    }
  }

  return submitToGreenhouseChain;
});
