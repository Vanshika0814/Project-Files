define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteXxreqJobReqRequestsChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.xxreqJobReqRequestsId 
     */
    async run(context, { xxreqJobReqRequestsId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_XxreqJobReqRequests',
        uriParams: {
          'XxreqJobReqRequests_Id': xxreqJobReqRequestsId,
        },
      }, { id: 'deleteXxreqJobReqRequests' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Delete failed',
          message: `Could not delete data: status ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_2026205369_2SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.xxreqJobReqRequestsListSDP2,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'XxreqJobReqRequests deleted',
        message: `XxreqJobReqRequests [${xxreqJobReqRequestsId}] successfully deleted`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteXxreqJobReqRequestsChain;
});
