define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveAndCloseChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $page.variables.saveXxreqJobReqRequestsChainInProgress = true;

      try {
        // Validates XxreqJobReqRequests form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        });

        if (!validateFormResult) {
          return;
        }

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $page.variables.xxreqJobReqRequests,
          fetchedRecord: $page.variables.fetchedXxreqJobReqRequests,
        });

        if (payload === undefined) {

          // KSY : Save and go to view page
          const toMainViewReqRequest2 = await Actions.navigateToPage(context, {
            page: 'main-view-req-request-ux' });
          // Return from the action chain when there are no changes to save
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_XxreqJobReqRequests',
          body: payload,
          uriParams: {
            'XxreqJobReqRequests_Id': $page.variables.xxreqJobReqRequestsId,
          },
        }, { id: 'saveXxreqJobReqRequests' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not update the Job Requisition Request: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        await Actions.fireNotificationEvent(context, {
          summary: 'Job Requests saved',
          message: 'Job Requisition Request record successfully updated',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // KSY : Save and go to view page
        const toMainViewReqRequest = await Actions.navigateToPage(context, {
          page: 'main-view-req-request-ux',
        });
      } finally {
        // Sets the progress variable to false
        $page.variables.saveXxreqJobReqRequestsChainInProgress = false;
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      let payload = updatedRecord;
      let hasChanges = true;
      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(Object.entries(payload).filter(([field, value]) =>
          JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
        ));
        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

  }


  return saveAndCloseChain;
});
