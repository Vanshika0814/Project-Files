define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      //console.log("start vb enter sss");


      const parentDepartments = await Actions.callRest(context, {
        endpoint: 'getall_valueSetsValues/getall_valueSets-values',
        uriParams: {
          'valueSets_Id': $application.constants.parentDepartmentValueSetCode,
          limit: 500
        },
        responseType: 'getallParentDepartmentsResponse',
      });

      $variables.parentDepartmentsObject.items = parentDepartments?.body?.items;

      await Actions.callChain(context, {
        chain: 'getall_organizationsFetch',
      });

      //get greenhouse custom field values
      const greenhouseCustomFieldsResponse = await Actions.callRest(context, {
        endpoint: 'getall_custom_fields_gh/get',
      });

      $variables.greenhouseCustomFields = greenhouseCustomFieldsResponse?.body;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.disableSubmitFlag',
          '$page.variables.readOnlySubmitFlag',
        ],
      });

      // KSY: Validate submit status to disable submit button
      const disableSubmitBtnFlagResult = await $functions.disableSubmitBtnFlag($variables.xxreqJobReqRequests.statusId);

      $variables.disableSubmitFlag = disableSubmitBtnFlagResult;

      const readOnlySubmitBtnFlagResult = await $functions.readOnlySubmitBtnFlag($variables.xxreqJobReqRequests.statusId);

      // KSY: Validate submit status to set read only controls
      $variables.readOnlySubmitFlag = readOnlySubmitBtnFlagResult;

      //console.log("end vb enter sss");

      
    }
  }

  return vbEnterListener;
});
