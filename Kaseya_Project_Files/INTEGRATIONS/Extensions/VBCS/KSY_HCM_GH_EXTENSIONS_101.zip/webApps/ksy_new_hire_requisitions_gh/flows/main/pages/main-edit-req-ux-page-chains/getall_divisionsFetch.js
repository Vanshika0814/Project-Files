define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getall_divisionsFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if (configuration.hookHandler.context.fetchOptions.filterCriterion) {



        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_valueSetsValues/getall_valueSets-values',
          uriParams: {
            'valueSets_Id': $application.constants.divisionValueSetCode,
            q: "EnabledFlag='Y' and upper(Value) LIKE '%" + configuration.hookHandler.context.fetchOptions.filterCriterion.text.toUpperCase() + "%'",

          },
          responseType: 'getall_DivisionsResponse',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
        });


        return callRestEndpoint1;
      } else {

        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_valueSetsValues/getall_valueSets-values',
          uriParams: {
            'valueSets_Id': $application.constants.divisionValueSetCode,
          },
          responseType: 'getall_DivisionsResponse',
          requestType: 'json',
          hookHandler: configuration.hookHandler,
          requestTransformOptions: {
            filter: {
              "op": "$eq",
              "attribute": "EnabledFlag",
              "value": "Y"
            }
          }
        });

        return callRestEndpoint1;

      }
    }
  }

  return getall_divisionsFetch;
});
