define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class submitXxreqJobReqRequestsChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions, $get } = context;
      try {
        // Sets the progress variable to true
        $page.variables.createXxreqJobReqRequestsChainInProgress = true;

        $variables.errorSubmitFlag = false;
        $variables.submitMessage = "";
        $variables.isSubmittedFlag = false;


        // Validates XxreqJobReqRequests form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validateXxreqJobReqRequests' });

        if (!validateFormResult) {
          return;
        }

        // KSY : Get datetime for submit date
        $variables.currentDateTime = await $functions.getCurrentDateTime();

        //save BO record
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_XxreqJobReqRequests',
          body: $page.variables.xxreqJobReqRequests,
        }, { id: 'createXxreqJobReqRequests' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new XxreqJobReqRequests: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          //To view page
          const toMainViewReqRequest = await Actions.navigateToPage(context, {
            page: 'main-view-req-request-ux'
          });
        }

        //Submit action init
        if (callRestResult.body?.requestId !== null && callRestResult.body?.requestId !== undefined) {

          //Get job request from BO to get generated requisition Name (YYMMDD-##)
          const jobRequestsResponse = await Actions.callRest(context, {
            endpoint: 'businessObjects/getall_XxreqJobReqRequests',
            uriParams: {
              fields: "ghRequisitionName",
              onlyData: 'true',
              q: "requestId=" + callRestResult.body.requestId,
            },
          });

          if (jobRequestsResponse.body.items[0].ghRequisitionName !== null && jobRequestsResponse.body.items[0].ghRequisitionName !== undefined) {

            let ghRequisitionId = jobRequestsResponse.body.items[0].ghRequisitionName;

            console.log("reqId:" + ghRequisitionId);

            //emq - only for test delete later            
            //$variables.xxreqJobReqRequests.ghRequisitionId = "20250731-2";
            //Init Prepare payload to greenhouse

            //Greenhouse template id
            $variables.jobPostHeader.template_job_id = $application.constants.templateJobId;

            //Number of openings
            $variables.jobPostHeader.number_of_openings = 1;

            //Job requisition name
            $variables.jobPostHeader.job_name = $variables.selectedJobData.data.JobName + " - " + ghRequisitionId;

            //Department
            $variables.jobPostHeader.external_department_id = $variables.xxreqJobReqRequests.departmentId;

            //Location: clear array first
            $variables.jobPostHeader.external_office_ids = [];

            $variables.jobPostHeader.external_office_ids.push($variables.selectedLocationData.data.LocationCode);

            //Requisition consecutive (YYMMDD-##)
            $variables.jobPostHeader.requisition_id = ghRequisitionId;

            ////start  validation custom fields - Validate custom fields

            //Validation for custom fields set to true initially
            $variables.customFieldsValidFlag = true;

            //Validation message for custom fields
            let customValidationMsg = "";
            let br = " ";

            //Job type
            const jobTypeValid = await $functions.validateGHFieldValue($variables.greenhouseCustomFields, 'job_type', $variables.selectedRequestTypeData.data.ghRequestTypeId);

            if (jobTypeValid === false) {
              customValidationMsg = "Job type value is not valid.";
              $variables.customFieldsValidFlag = false;
            } else {
              $variables.jobPatchFields.custom_fields.push({ "name_key": "job_type", "value": $variables.selectedRequestTypeData.data.ghRequestTypeId });
            }

            //Employment type
            const employmentTypeValid = await $functions.validateGHFieldValue($variables.greenhouseCustomFields, 'employment_type', $variables.selectedEmploymentTypeData.data.ghEmplTypeId);

            if (employmentTypeValid === false) {
              customValidationMsg = "Employment type value is not valid.";
              $variables.customFieldsValidFlag = false;
            } else {
              $variables.jobPatchFields.custom_fields.push({ "name_key": "employment_type", "value": $variables.selectedEmploymentTypeData.data.ghEmplTypeId });
            }

            //If engineering flag is true validate module and suite and add to payload
            if ($variables.xxreqJobReqRequests.rdOrSupportFlag === true) {

              //Suite
              const productValid = await $functions.validateGHFieldValue($variables.greenhouseCustomFields, "product", $variables.selectedSuiteData.data.Value);

              if (productValid === false) {
                customValidationMsg += br + "Suite value '" + $variables.selectedSuiteData.data.Value + "' is not valid.";
                $variables.customFieldsValidFlag = false;
              } else {
                $variables.jobPatchFields.custom_fields.push({ "name_key": "product", "value": $variables.selectedSuiteData.data.Value }); //suite

              }

              //Module
              const moduleValid = await $functions.validateGHFieldValue($variables.greenhouseCustomFields, "module", $variables.selectedModuleData.data.Value);

              if (moduleValid === false) {
                customValidationMsg += br + "Module value '" + $variables.selectedModuleData.data.Value + "' is not valid.";
                $variables.customFieldsValidFlag = false;
              } else {
                $variables.jobPatchFields.custom_fields.push({ "name_key": "module", "value": $variables.selectedModuleData.data.Value });
              }
            }

            //Division
            const divisionValid = await $functions.validateGHFieldValue($variables.greenhouseCustomFields, "division", $variables.selectedDivisionData.data.Value);

            if (divisionValid === false) {
              customValidationMsg += br + "Division value '" + $variables.selectedDivisionData.data.Value + "' is not valid.";
              $variables.customFieldsValidFlag = false;
            } else {
              $variables.jobPatchFields.custom_fields.push({ "name_key": "division", "value": $variables.selectedDivisionData.data.Value });
            }

            //Budget Holder : get budgeter email from oracle; Validate exists as user in GH
            if ($variables.selectedBudgetHolderData.data.PersonId !== null && $variables.selectedBudgetHolderData.data.PersonId !== undefined) {
              const budgeterResponse = await Actions.callRest(context, {
                endpoint: 'getall_publicWorkers_emp/getall_publicWorkers',
                uriParams: {
                  onlyData: 'true',
                  fields: 'WorkEmail',
                  q: "PersonId=" + $variables.selectedBudgetHolderData.data.PersonId,
                },
              });

              if (budgeterResponse.body.items[0]?.WorkEmail !== null && budgeterResponse.body.items[0]?.WorkEmail !== undefined) {

                const managerResponse = await Actions.callRest(context, {
                  endpoint: 'getall_users_gh/getall_users_gh',
                  uriParams: {
                    email: budgeterResponse.body.items[0]?.WorkEmail,
                  },
                });

                if (managerResponse.body?.id === null || managerResponse.body?.id === undefined) {
                  customValidationMsg += br + "Budget holder is not valid.";
                  $variables.customFieldsValidFlag = false;
                } else {
                  $variables.jobPatchFields.custom_fields.push({ "name_key": "budgeter", "value": budgeterResponse.body.items[0]?.WorkEmail });
                }
              } else {
                customValidationMsg += br + "The selected Budget holder email is not valid in Oracle.";
                $variables.customFieldsValidFlag = false;
              }
            } else {
              customValidationMsg += br + "The selected Budget holder is not valid in Oracle.";
              $variables.customFieldsValidFlag = false;
            }

            console.log("validation result: " + $variables.customFieldsValidFlag);


            //Requestor : get requestor email from logged user; Validate if exists as user in GH (BO-154)
            const requestorResponse = await Actions.callRest(context, {
              endpoint: 'getall_users_gh/getall_users_gh',
              uriParams: {
                email: $application.user.email,
              },
            });

            if (requestorResponse.body?.id === null || requestorResponse.body?.id === undefined) {
              customValidationMsg += br + "Requestor is not valid.";
              $variables.customFieldsValidFlag = false;
            } else {
              $variables.jobPatchFields.custom_fields.push({ "name_key": "requestor", "value": $application.user.email });
            }

            console.log("validation result: " + $variables.customFieldsValidFlag);

            //End of changes (BO-154)

            //If is backfill or shadow add to payload
            if ($variables.xxreqJobReqRequests.reqTypeId === $application.constants.backFillTypeId ||
              $variables.xxreqJobReqRequests.reqTypeId === $application.constants.shadowTypeId) {

              //Backfill name : Employee
              $variables.jobPatchFields.custom_fields.push({ "name_key": "backfill_name", "value": $variables.selectedEmployeeData.data.DisplayName + " - " + $variables.selectedEmployeeData.data.PersonNumber });

              //Termination date
              $variables.jobPatchFields.custom_fields.push({ "name_key": "termination_date", "value": $variables.xxreqJobReqRequests.exitDate });
            }

            //Manage others
            $variables.jobPatchFields.custom_fields.push({
              "name_key": "manage_others", "value": ($variables.xxreqJobReqRequests.manageOthersFlag === null ||
                $variables.xxreqJobReqRequests.manageOthersFlag === undefined) ? "false" : $variables.xxreqJobReqRequests.manageOthersFlag
            });

            //Job code (Job title)
            $variables.jobPatchFields.custom_fields.push({ "name_key": "job_code_job_1750947121.7309973", "value": $variables.selectedJobData.data.JobCode });

            //Manager level
            $variables.jobPatchFields.custom_fields.push({ "name_key": "management_level", "value": $variables.selectedManagementLevelData.data.Meaning });

            //Salary
            $variables.jobPatchFields.custom_fields.push({
              "name_key": "salary_job_1641382351.3796115",
              "min_value": $variables.xxreqJobReqRequests.salaryBase,
              "max_value": $variables.xxreqJobReqRequests.salaryBase,
              "unit": "USD"
            });

            //Variable salary
            $variables.jobPatchFields.custom_fields.push({
              "name_key": "salary",
              "min_value": $variables.xxreqJobReqRequests.variableSalary,
              "max_value": $variables.xxreqJobReqRequests.variableSalary,
              "unit": "USD"
              //variable salary
            });

            //BO-156
            //Salary local
            if ($variables.xxreqJobReqRequests.salaryBaseLocal != null && $variables.xxreqJobReqRequests.currency != null && $variables.xxreqJobReqRequests.variableSalaryLocal != null) {
              $variables.jobPatchFields.custom_fields.push({
                "name_key": "salary_range__local_currency_",
                "value": $variables.xxreqJobReqRequests.salaryBaseLocal,
                "unit": $variables.xxreqJobReqRequests.currency
              });

              //Variable salary local
              $variables.jobPatchFields.custom_fields.push({
                "name_key": "variable_compensation__local_currency_",
                "value": $variables.xxreqJobReqRequests.variableSalaryLocal,
                "unit": $variables.xxreqJobReqRequests.currency
              });
            }

            //End of changes BO-156

            //Description
            $variables.jobPatchFields.team_and_responsibilities = $variables.xxreqJobReqRequests.jobDesc;
            //console.log("array test" + $variables.jobPatchFields.custom_fields[0]);

            //Reporting manager
            if ($variables.selectedManagerData.data.WorkEmail !== null && $variables.selectedManagerData.data.WorkEmail !== undefined) {

              const managerResponse = await Actions.callRest(context, {
                endpoint: 'getall_users_gh/getall_users_gh',
                uriParams: {
                  email: $variables.selectedManagerData.data.WorkEmail,
                },
              });

              if (managerResponse.body?.id !== null && managerResponse.body?.id !== undefined) {

                $variables.jobPostHiringManager.hiring_managers.push({ "user_id": managerResponse.body.id });
              } else {
                customValidationMsg += br + "The selected Reporting manager is not valid.";
                $variables.customFieldsValidFlag = false;
              }
            } else {
              customValidationMsg += br + "The selected Reporting manager's email is not valid in Oracle.";
              $variables.customFieldsValidFlag = false;
            }

            //Hiring manager roleId
            if ($application.variables.ghHiringManRoleId === null || $application.variables.ghHiringManRoleId === undefined) {
              customValidationMsg += br + "The Hiring manager job role is not valid.";
              $variables.customFieldsValidFlag = false;
            }

            //If fields validation is ok
            if ($variables.customFieldsValidFlag === true) {


              //Post job to Greenhouse (Header)
              const jobPostResponse = await Actions.callRest(context, {
                endpoint: 'post_job_gh/post_job',
                headers: {
                  'on-behalf-of': $application.constants.onBehalfOfId,
                },
                body: $variables.jobPostHeader,
              });

              if (!jobPostResponse.ok) {
                $variables.errorSubmitFlag = true;
                $variables.submitMessage = "The request '" + $variables.selectedJobData.data.JobName + " - " + ghRequisitionId + "' couldn't be submitted: " + jobPostResponse.body?.errors[0]?.message + " Status " + jobPostResponse.status + ". ";
                $variables.isSubmittedFlag = false;

                //Update message field : Add current time to force field change to run email notification trigger
                $variables.xxreqJobReqRequests.submitMessage = $variables.submitMessage + " - " + $variables.currentDateTime;

                const callUpdateResult = await Actions.callRest(context, {
                  endpoint: 'businessObjects/update_XxreqJobReqRequests',
                  body: $page.variables.xxreqJobReqRequests,
                  uriParams: {
                    'XxreqJobReqRequests_Id': callRestResult.body?.requestId,
                  },
                }, { id: 'saveXxreqJobReqRequests' });

                if (!callUpdateResult.ok) {
                  // Create error message
                  const errorUpdateMessage = callUpdateResult.body?.detail || callUpdateResult.body?.['o:errorDetails']?.[0]?.detail || `Could not save the Job Requisition Request as submitted: status ${callUpdateResult.status}`;
                  // Fires a notification event about failed save
                  await Actions.fireNotificationEvent(context, {
                    summary: 'Save failed',
                    message: errorUpdateMessage,
                  }, { id: 'fireErrorNotification' });
                }

                // Fires a notification event about failed save
                await Actions.fireNotificationEvent(context, {
                  summary: 'Submit failed',
                  message: $variables.submitMessage,
                }, { id: 'fireErrorNotification' });

                //To view page
                const toMainViewReqRequest = await Actions.navigateToPage(context, {
                  page: 'main-view-req-request-ux'
                });

                return;

              }

              $variables.errorSubmitFlag = false;
              $variables.isSubmittedFlag = true;
              $variables.submitMessage = "Job Header created for the request '" + $variables.selectedJobData.data.JobName + " - " + ghRequisitionId + "'. ";

              console.log("Response id " + jobPostResponse.body.id);

              //update custom fields
              if (jobPostResponse.body.id !== null && jobPostResponse.body.id !== undefined) {

                let jobRequestIdGH = jobPostResponse.body.id;

                //Rest to update custom field values
                const jobPatchResponse = await Actions.callRest(context, {
                  endpoint: 'patch_job_gh/patch_job',
                  uriParams: {
                    jobId: jobRequestIdGH,
                  },
                  body: $variables.jobPatchFields,
                  headers: {
                    'on-behalf-of': $application.constants.onBehalfOfId,
                  },
                });

                if (!jobPatchResponse.ok) {
                  //Submited with errors custom fields
                  $variables.errorSubmitFlag = true;
                  $variables.isSubmittedFlag = true;
                  $variables.submitMessage = "The request '" + $variables.selectedJobData.data.JobName + " - " + ghRequisitionId + "' was submitted with errors: " + jobPatchResponse.body?.errors[0]?.message + ". Status " + jobPatchResponse.status + ". ";
                }

                //Add role to the hiring manager for the created job
                if ($application.variables.ghHiringManRoleId !== null && $application.variables.ghHiringManRoleId != undefined) {
                  const roleAssignResponse = await Actions.callRest(context, {
                    endpoint: 'put_userPermissionJob_gh/put',
                    uriParams: {
                      userId: $variables.jobPostHiringManager.hiring_managers[0].user_id,
                    }, headers: {
                      'on-behalf-of': $application.constants.onBehalfOfId,
                    },
                    body: {
                      job_id: jobRequestIdGH,
                      user_role_id: $application.variables.ghHiringManRoleId
                    },
                  });

                  if (!roleAssignResponse.ok) {
                    if ($variables.errorSubmitFlag === false) {
                      $variables.submitMessage = "The request '" + $variables.selectedJobData.data.JobName + " - " + ghRequisitionId + "' was submitted with errors: " + roleAssignResponse.body?.errors[0]?.message + " Status " + roleAssignResponse.status + ". ";
                      $variables.errorSubmitFlag = true;
                    } else {
                      $variables.submitMessage += " - " + roleAssignResponse.body?.errors[0]?.message + " Status " + roleAssignResponse.status + ". ";
                    }
                    $variables.isSubmittedFlag = true;
                  }
                } else {
                  if ($variables.errorSubmitFlag === false) {
                    $variables.submitMessage = "The request '" + $variables.selectedJobData.data.JobName + " - " + ghRequisitionId + "' was submitted with errors: The hiring manager role is not valid. ";
                    $variables.errorSubmitFlag = true;
                  } else {
                    $variables.submitMessage += " - The hiring manager role is not valid.";
                  }
                  $variables.isSubmittedFlag = true;
                }

                //Add Hiring team
                const jobHiringTeamResponse = await Actions.callRest(context, {
                  endpoint: 'post_job_hiring_team/post_job_hiring_team',
                  uriParams: {
                    jobId: jobRequestIdGH,
                  },
                  headers: {
                    'on-behalf-of': $application.constants.onBehalfOfId,
                  },
                  body: $variables.jobPostHiringManager,
                });

                if (!jobHiringTeamResponse.ok) {

                  if ($variables.errorSubmitFlag === false) {
                    $variables.submitMessage = "The request '" + $variables.selectedJobData.data.JobName + " - " + ghRequisitionId + "' was submitted with errors: " + jobHiringTeamResponse.body?.errors[0]?.message + " Status " + jobHiringTeamResponse.status + ". ";
                    $variables.errorSubmitFlag = true;
                  } else {
                    $variables.submitMessage += " - " + jobHiringTeamResponse.body?.errors[0]?.message + " Status " + jobHiringTeamResponse.status + ". ";
                  }
                  $variables.isSubmittedFlag = true;
                }

                if ($variables.errorSubmitFlag === false) {

                  //All data sent to greenhouse
                  $variables.errorSubmitFlag = false;
                  $variables.isSubmittedFlag = true;
                  $variables.submitMessage = "New Hire Request record successfully created and submitted. '" + $variables.selectedJobData.data.JobName + " - " + ghRequisitionId + "'. ";
                }



                //Add job post location (BO-157)
                const jobPostGet = await Actions.callRest(context, {
                  endpoint: 'getAll_jobPosts_gh/get',
                  uriParams: {
                    id: jobRequestIdGH,
                  },
                });

                let jobPostId = jobPostGet.body[0].id;
                let jobPostRequest = {
                  location: $variables.selectedLocationData.data.LocationName
                };
                const response = await Actions.callRest(context, {
                  endpoint: 'patch_jobPosts_gh/patch_jobPost',
                  uriParams: {
                    id: jobPostId,
                  },
                  headers: {
                    'on-behalf-of': $application.constants.onBehalfOfId,
                  },
                  body: jobPostRequest,
                });



                //End of changes

              } else {
                $variables.errorSubmitFlag = true;
                $variables.isSubmittedFlag = true;
                $variables.submitMessage = "The request was submitted with errors: Submitted Job request not returning a Greenhouse record identifier. ";
              }
            } else {
              $variables.errorSubmitFlag = true;
              $variables.isSubmittedFlag = false;
              $variables.submitMessage = "The request '" + $variables.selectedJobData.data.JobName + " - " + ghRequisitionId + "' was not submitted: Field validation: " + br + customValidationMsg;
            }
          } else {
            $variables.errorSubmitFlag = true;
            $variables.isSubmittedFlag = false;
            $variables.submitMessage = "The request couldn't be submitted: Saved Job request not returning a record identifier. ";
          }
        } else {
          $variables.errorSubmitFlag = true;
          $variables.isSubmittedFlag = false;
          $variables.submitMessage = "The request couldn't be submitted: Saved Job request not returning a record identifier. ";
        }

        //Fire notification based on results
        //Update message field : Add current time to force field change to run email notification trigger
        $variables.xxreqJobReqRequests.submitMessage = $variables.submitMessage + " - " + $variables.currentDateTime;

        //Update BO record to submited as header has been submitted to GH 
        // KSY: Update updated by
        $variables.xxreqJobReqRequests.lastUpdatedBy = $application.user.username;
        // KSY: Update updated date
        $variables.xxreqJobReqRequests.lastUpdateDate = $variables.currentDateTime;

        if ($variables.isSubmittedFlag === true) {

          // KSY: Update status to submitted
          $variables.xxreqJobReqRequests.statusId = $application.constants.submittedStatusId;
          // KSY: Update submitted by
          $variables.xxreqJobReqRequests.submittedBy = $application.user.username;
          // KSY: Update submitted date
          $variables.xxreqJobReqRequests.submitDate = $variables.currentDateTime;
        }

        const callUpdateResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_XxreqJobReqRequests',
          body: $page.variables.xxreqJobReqRequests,
          uriParams: {
            'XxreqJobReqRequests_Id': callRestResult.body?.requestId,
          },
        }, { id: 'saveXxreqJobReqRequests' });

        if (!callUpdateResult.ok) {
          // Create error message
          const errorUpdateMessage = callUpdateResult.body?.detail || callUpdateResult.body?.['o:errorDetails']?.[0]?.detail || `Could not save the Job Requisition Request as submitted: status ${callUpdateResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorUpdateMessage,
          }, { id: 'fireErrorNotification' });
        }

        let summryMsg = "Ok";

        let typeMsg = "error";

        if ($variables.errorSubmitFlag === true && $variables.isSubmittedFlag === true) {
          typeMsg = "warning";
          summryMsg = "Job requisition submitted with errors";
        } else if ($variables.errorSubmitFlag === false && $variables.isSubmittedFlag === true) {
          typeMsg = "confirmation";
          summryMsg = "Job requisition request submitted succesfully";
        } else {
          typeMsg = "error";
          summryMsg = "Job requisition request submit failed";
        }

        // Fires a notification event about submit result
        await Actions.fireNotificationEvent(context, {
          summary: summryMsg,
          message: $variables.submitMessage + " - " + $variables.currentDateTime,
          displayMode: 'persist',
          type: typeMsg,
        }, { id: 'fireSuccessNotification' });

        //To view page
        const toMainViewReqRequest = await Actions.navigateToPage(context, {
          page: 'main-view-req-request-ux',
        });

      } catch (error) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Submit failed',
          message: error,
        }, { id: 'fireErrorNotification' });

        //To view page
        const toMainViewReqRequest = await Actions.navigateToPage(context, {
          page: 'main-view-req-request-ux',
        });



      } finally {
        // Sets the progress variable to false
        $page.variables.createXxreqJobReqRequestsChainInProgress = false;
      }
    }
  }

  return submitXxreqJobReqRequestsChain;
});
