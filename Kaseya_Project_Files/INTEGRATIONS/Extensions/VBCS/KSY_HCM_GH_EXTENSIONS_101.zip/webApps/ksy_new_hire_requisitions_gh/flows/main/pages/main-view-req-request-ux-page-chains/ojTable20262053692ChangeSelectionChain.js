define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable20262053692ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.xxreqJobReqRequestsId
     */
    async run(context, { xxreqJobReqRequestsId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.oj_table_2026205369_2SelectedId = xxreqJobReqRequestsId;
    }
  }

  return ojTable20262053692ChangeSelectionChain;
});
