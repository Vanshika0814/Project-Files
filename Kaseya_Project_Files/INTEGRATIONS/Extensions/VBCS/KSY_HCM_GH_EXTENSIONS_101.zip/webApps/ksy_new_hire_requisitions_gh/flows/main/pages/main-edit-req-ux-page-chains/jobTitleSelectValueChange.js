define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class jobTitleSelectValueChange extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if ($variables.firstExecution === false) {
        if (data?.ManagerLevel !== null && data?.ManagerLevel !== undefined) {

          const managerLevelsResponse = await Actions.callRest(context, {
            endpoint: 'getall_commonLookup_Codes/getall_commonLookups-lookupCodes',
            uriParams: {
              'commonLookups_Id': $application.constants.managerLevelLkupType,
              q: "LookupCode='" + data.ManagerLevel +"'"
            },
          });


          //jobTitleResponse.body.items[0]?.ManagerLevel

          if (managerLevelsResponse.body.items[0]?.LookupCode !== null && managerLevelsResponse.body.items[0]?.LookupCode !== undefined) {
            $variables.xxreqJobReqRequests.jobLevelId = managerLevelsResponse.body.items[0].LookupCode;
          }
          //$variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].ManagerLevel = managerLevelsResponse.body.items[0]?.Meaning;
        } else {

          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.xxreqJobReqRequests.jobLevelId',
            ],
          });
        }
      }
    }
  }

  return jobTitleSelectValueChange;
});
