define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getall_XxreqJobReqRequestsFetch2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables, $eq, $functions, $and } = context;
      $variables.user = $application.user.userId + " " + $application.user.email + " " + $application.user.username;

      let jobRequestsResponse = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_XxreqJobReqRequests',
        requestTransformOptions: {
          filter: {
            op: '$and',
            criteria: [
              {
                op: '$eq',
                attribute: 'statusIdObject.statusId',
                value: '1',
              },
              {
                op: '$eq',
                attribute: 'createdBy',
                value: $application.user.username,
              },
            ],
          },
        },
        responseBodyFormat: 'json',
        responseType: 'getallXxreqJobReqRequestsResponse',
      });

      if ($variables.jobTitlesArray.length === 0 || $variables.departmentsObject.items.length === 0 || $variables.locationsObject.items.length === 0) {
        await Actions.callChain(context, {
          chain: 'loadComplementData',
        });
      }

      const mergeAllRequestData = await $functions.mergeAllRequestData(jobRequestsResponse.body.items, $variables.jobTitlesArray, $variables.departmentsObject.items, $variables.locationsObject.items);

      jobRequestsResponse.body.items = mergeAllRequestData;

      return jobRequestsResponse;
    }
  }

  return getall_XxreqJobReqRequestsFetch2;
});
