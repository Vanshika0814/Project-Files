define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getall_managerLevels_CodesFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if (configuration.hookHandler.context.fetchOptions.filterCriterion) {

        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_commonLookup_Codes/getall_commonLookups-lookupCodes',
          uriParams: {
            'commonLookups_Id': $application.constants.managerLevelLkupType,
            q: "EnabledFlag = 'Y' and upper(Meaning) LIKE '%" + configuration.hookHandler.context.fetchOptions.filterCriterion.text.toUpperCase() + "%'",

          },
          responseType: 'getallManagerLevelResponse',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
        });

        return callRestEndpoint1;
      } else {
        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_commonLookup_Codes/getall_commonLookups-lookupCodes',
          uriParams: {
            'commonLookups_Id': $application.constants.managerLevelLkupType,
          },
          responseType: 'getallManagerLevelResponse',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
          requestTransformOptions: {
            filter: {
              "op": "$eq",
              "attribute": "EnabledFlag",
              "value": "Y"
            }
          },
        });

        return callRestEndpoint1;
      }
    }
  }

  return getall_managerLevels_CodesFetch;
});
