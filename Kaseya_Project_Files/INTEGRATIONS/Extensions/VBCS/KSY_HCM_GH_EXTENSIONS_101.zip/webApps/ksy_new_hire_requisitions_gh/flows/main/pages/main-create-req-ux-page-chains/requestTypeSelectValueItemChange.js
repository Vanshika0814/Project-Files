define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class requestTypeSelectValueItemChange extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      console.log($variables.xxreqJobReqRequests.reqTypeId);
      console.log(typeof $variables.xxreqJobReqRequests.reqTypeId);
      console.log($application.constants.backFillTypeId);
      console.log(typeof $application.constants.backFillTypeId);
      console.log($application.constants.shadowTypeId);
      console.log(typeof $application.constants.shadowTypeId);
      console.log(key);
      console.log(typeof key);

      if (key !== $application.constants.backFillTypeId && key !== $application.constants.shadowTypeId) {
        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.xxreqJobReqRequests.empId',
    '$page.variables.selectedEmployeeData.data',
  ],
        });

        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.workerDetails.data',
          ],
        });
      }
    }
  }

  return requestTypeSelectValueItemChange;
});
