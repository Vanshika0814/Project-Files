define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getall_XxreqJobReqRequestsFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.configuration 
     * @return {getallXxreqJobReqRequestsResponse} 
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables, $functions, $eq, $and } = context;

      console.log("In fetch1");

      let jobRequestsResponse = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_XxreqJobReqRequests',
        hookHandler: configuration?.hookHandler,
        requestType: 'json',
        requestTransformOptions: {
          filter: {
            op: '$and',
            criteria: [
              {
                op: '$eq',
                attribute: 'statusIdObject.statusId',
                value: '2',
              },
              {
                op: '$eq',
                attribute: 'createdBy',
                value: $application.user.username,
              },
            ],
          },
        },
        responseBodyFormat: 'json',
      });

      if ($variables.jobTitlesArray.length === 0 || $variables.departmentsObject.items.length === 0 || $variables.locationsObject.items.length === 0) {

        await Actions.callChain(context, {
          chain: 'loadComplementData',
        });
      }

      //$variables.jobTitlesArray is populated in vbenter event
      const mergeAllRequestData = await $functions.mergeAllRequestData(jobRequestsResponse.body.items, $variables.jobTitlesArray, $variables.departmentsObject.items, $variables.locationsObject.items);

      jobRequestsResponse.body.items = mergeAllRequestData;

      return jobRequestsResponse;
    }
  }

  return getall_XxreqJobReqRequestsFetch;
});
