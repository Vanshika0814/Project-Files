define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getall_employeesFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.configuration 
     * @return {getallPublicWorkersEmployees} 
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (configuration.hookHandler.context.fetchOptions.filterCriterion) {
        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_publicWorkers_emp/getall_publicWorkers',
          responseType: 'getallPublicWorkersEmployees',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
          uriParams: {
            q: "((PersonNumber LIKE '%" + configuration.hookHandler.context.fetchOptions.filterCriterion.text + "%') or (upper(DisplayName) LIKE '%" + configuration.hookHandler.context.fetchOptions.filterCriterion.text.toUpperCase() + "%'))",
            orderBy: 'DisplayName',
          },
        });

      return callRestEndpoint1;
      }else{
        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_publicWorkers_emp/getall_publicWorkers',
          responseType: 'getallPublicWorkersEmployees',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
          uriParams: {
            orderBy: 'DisplayName',
          },
        });

      return callRestEndpoint1;
      }

      
    }
  }

  return getall_employeesFetch;
});
