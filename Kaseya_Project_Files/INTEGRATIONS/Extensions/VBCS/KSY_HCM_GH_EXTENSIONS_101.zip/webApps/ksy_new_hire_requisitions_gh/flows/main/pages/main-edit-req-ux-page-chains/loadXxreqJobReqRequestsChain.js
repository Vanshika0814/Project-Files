define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadXxreqJobReqRequestsChain extends ActionChain {

    /**
    * @param {Object} context
    */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      //console.log("start vb load sss");
      $page.variables.isInitializing = true;
      $variables.disableSubmitFlag = true;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_XxreqJobReqRequests',
        responseType: 'getXxreqJobReqRequestsResponse',
        uriParams: {
          'XxreqJobReqRequests_Id': $page.variables.xxreqJobReqRequestsId,
        },
      }, { id: 'loadXxreqJobReqRequests' });

      if (!callRestResult.ok) {
        // Create error message
        const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not load data: status ${callRestResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });

        return;
      }

      $page.variables.fetchedXxreqJobReqRequests = callRestResult.body;
      $page.variables.xxreqJobReqRequests = $page.variables.fetchedXxreqJobReqRequests;
      $page.variables.xxreqJobReqRequestsETag = callRestResult.headers.get('ETag');

      const response = await Actions.callRest(context, {
        endpoint: 'getCurrencies/getall_currenciesLOV',
        uriParams: {
          onlyData: true,
          q: "EnabledFlag='Y'",
          limit: 500,
        },
        headers: {
          'REST-Framework-Version': '4',
        },
      });

      $variables.currenciesLov.data = response.body.items;
      $page.variables.isInitializing = true;
      console.log('valor del bool',$page.variables.isInitializing);
      
      console.log('valor en el enter',$page.variables.xxreqJobReqRequests.currency);
      //$page.variables.isInitializing = false;
      //console.log('set a false');
      //console.log('statusNameq:' + $page.variables.xxreqJobReqRequests.statusIdObject.items[0].statusName);

      /* move logic to vb enter to avoid enable button before load all data
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.disableSubmitFlag',
          '$page.variables.readOnlySubmitFlag',
        ],
      });

      // KSY: Validate submit status to disable submit button
      const disableSubmitBtnFlagResult = await $functions.disableSubmitBtnFlag($variables.xxreqJobReqRequests.statusId);

      $variables.disableSubmitFlag = disableSubmitBtnFlagResult;

      const readOnlySubmitBtnFlagResult = await $functions.readOnlySubmitBtnFlag($variables.xxreqJobReqRequests.statusId);

      // KSY: Validate submit status to set read only controls
      $variables.readOnlySubmitFlag = readOnlySubmitBtnFlagResult;

      console.log("end vb load sss");
    */
    }
  }

  return loadXxreqJobReqRequestsChain;
});
