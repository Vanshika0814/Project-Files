define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getall_organizationsFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      if (configuration?.hookHandler?.context?.fetchOptions?.filterCriterion) {

        const organizationsResponse = await Actions.callRest(context, {
          endpoint: 'getall_organizations/getLatestOrganizations',
          responseType: 'getallOrganizationsResponse',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
          uriParams: {
            q: "upper(Name) LIKE '%" + configuration.hookHandler.context.fetchOptions.filterCriterion.text.toUpperCase() + "%' and Status='A' and ClassificationCode='DEPARTMENT' and OrganizationDFF.ksyGreenhouseParentid IS NOT NULL",
            orderBy: "Name",

          },
        });

        //the variable parentDepartmentsObject is populated in vbenter event
        const mergeDepartmentsData = await $functions.mergeDepartmentsData(organizationsResponse, $variables.parentDepartmentsObject);

        return mergeDepartmentsData;

      } else {

        const organizationsResponse = await Actions.callRest(context, {
          endpoint: 'getall_organizations/getLatestOrganizations',
          responseType: 'getallOrganizationsResponse',
          requestType: 'json',
          uriParams: {
            orderBy: "Name",
            q: "Status='A' and ClassificationCode='DEPARTMENT' and OrganizationDFF.ksyGreenhouseParentid IS NOT NULL",

          },
        });

        //the variable parentDepartmentsObject is populated in vbenter event
        const mergeDepartmentsData = await $functions.mergeDepartmentsData(organizationsResponse, $variables.parentDepartmentsObject);


        return mergeDepartmentsData;


      }
    }
  }

  return getall_organizationsFetch;
});
