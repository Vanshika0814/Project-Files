define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const parentDepartments = await Actions.callRest(context, {
        endpoint: 'getall_valueSetsValues/getall_valueSets-values',
        uriParams: {
          'valueSets_Id': $application.constants.parentDepartmentValueSetCode,
          limit: 500
        },
        responseType: 'getallParentDepartmentsResponse',
      });

      $variables.parentDepartmentsObject.items = parentDepartments?.body?.items;

      //get greenhouse custom field values
      const greenhouseCustomFieldsResponse = await Actions.callRest(context, {
        endpoint: 'getall_custom_fields_gh/get',
      });

      $variables.greenhouseCustomFields = greenhouseCustomFieldsResponse?.body;

      const response = await Actions.callRest(context, {
        endpoint: 'getCurrencies/getall_currenciesLOV',
        uriParams: {
          onlyData: true,
          q: "EnabledFlag='Y'",
          limit: 500,
        },
        headers: {
          'REST-Framework-Version': '4',
        },
      });

      $variables.currenciesLov.data = response.body.items;

    }
  }

  return vbEnterListener;
});
