define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadComplementData extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const departmentsResponse = await Actions.callRest(context, {
        endpoint: 'getall_departments/getall_departmentsLov',
        uriParams: {
          onlyData: true,
          limit: 500,
        },
        responseType: 'getall_departmentsLov',
        responseBodyFormat: 'json',
      });

      if (departmentsResponse?.body?.items?.length > 0) {
        $variables.departmentsObject.items = departmentsResponse.body.items;
      }

      const locationsResponse = await Actions.callRest(context, {
        endpoint: 'getall_locations/getall_locations',
        responseType: 'getall_locationsLov',
        uriParams: {
          onlyData: true,
          limit: 500,
        },
        responseBodyFormat: 'json',
      });

      if (locationsResponse?.body?.items?.length > 0) {
        $variables.locationsObject.items = locationsResponse.body.items;
      }

      // Var to store all job titles. Used by recursive action chain getJobTitles
      $variables.jobTitlesArray = [];

      // Gets all job titles loop by offset parameter. More than 500. Storing result in page var jobTitlesArray
      await Actions.callChain(context, {
        chain: 'getJobTitles',
        params: {
          offSetParam: 0,
          limitParam: 500,
          accumulator: $variables.jobTitlesArray,
        },
      }, { id: 'getJobTiltesREcursive' });

    }
  }

  return loadComplementData;
});
