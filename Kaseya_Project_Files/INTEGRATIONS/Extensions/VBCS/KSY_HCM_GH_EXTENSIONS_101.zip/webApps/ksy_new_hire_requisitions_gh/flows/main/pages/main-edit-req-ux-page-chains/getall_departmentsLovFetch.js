define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getall_departmentsLovFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (configuration.hookHandler.context.fetchOptions.filterCriterion) {
      const callRestEndpoint1 = await Actions.callRest(context, {
        endpoint: 'getall_departments/getall_departmentsLov',
        uriParams: {
          onlyData: true,
          fields: 'OrganizationId,Name',
          q: "upper(Name) LIKE '%" + configuration.hookHandler.context.fetchOptions.filterCriterion.text.toUpperCase() + "%'",
          orderBy: "Name",
        },
        responseType: 'getallDepartmentsLovResponse',
        hookHandler: configuration.hookHandler,
        requestType: 'json',
      });

      return callRestEndpoint1;

     } else {
        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'getall_departments/getall_departmentsLov',
          uriParams: {
            onlyData: true,
            fields: 'OrganizationId,Name',
            orderBy: "Name",
          },
          responseType: 'getallDepartmentsLovResponse',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
        });

      return callRestEndpoint1;
      }
    }
  }

  return getall_departmentsLovFetch;
});
