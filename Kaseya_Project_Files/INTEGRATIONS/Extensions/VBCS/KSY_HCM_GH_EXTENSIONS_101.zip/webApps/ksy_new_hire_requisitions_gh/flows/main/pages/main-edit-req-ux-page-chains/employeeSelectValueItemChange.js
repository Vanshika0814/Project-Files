define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class employeeSelectValueItemChange extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      if ($variables.readOnlySubmitFlag === false) {

        $variables.expandEmployeePanel = $variables.expandEmployeePanel === true ? true : false;

        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.workerDetails.data',
          ],
        });

        const workerDetailResponse = await Actions.callRest(context, {
          endpoint: 'getall_workerDetails/getall_workers',
          uriParams: {
            q: "PersonId=" + key,
            expand: 'workRelationships.assignments.assignmentsDFF',
          },
        });

        $variables.workerDetails.data = workerDetailResponse.body.items;

        if ($variables.firstExecution === false) {
          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.xxreqJobReqRequests.jobTitleId',
              '$page.variables.xxreqJobReqRequests.jobLevelId',
              '$page.variables.xxreqJobReqRequests.departmentId',
              '$page.variables.xxreqJobReqRequests.locationId',
              '$page.variables.xxreqJobReqRequests.divisionId',
              '$page.variables.xxreqJobReqRequests.moduleId',
              '$page.variables.xxreqJobReqRequests.suiteId',
              '$page.variables.xxreqJobReqRequests.rdOrSupportFlag'
            ],
          });
          $variables.xxreqJobReqRequests.departmentId = $variables.workerDetails.data[0]?.workRelationships.items[0]?.assignments.items[0]?.DepartmentId;
          $variables.xxreqJobReqRequests.locationId = $variables.workerDetails.data[0]?.workRelationships.items[0]?.assignments.items[0]?.LocationId;
        }

        $variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].JobTitle = undefined;

        if ($variables.workerDetails.data[0]?.workRelationships.items[0]?.assignments.items[0]?.JobId !== null) {
          const jobTitleResponse = await Actions.callRest(context, {
            endpoint: 'getall_jobTitles/getall_jobsLov',
            uriParams: {
              q: "JobId=" + $variables.workerDetails.data[0]?.workRelationships.items[0]?.assignments.items[0]?.JobId.toString(),
            },
          });

          $variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].JobTitle = jobTitleResponse.body.items[0]?.JobName;
          if ($variables.firstExecution === false) {
            $variables.xxreqJobReqRequests.jobTitleId = $variables.workerDetails.data[0]?.workRelationships.items[0]?.assignments.items[0]?.JobId;
          }
          $variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].ManagerLevel = undefined;

          if (jobTitleResponse.body.items[0]?.ManagerLevel !== null) {

            const managerLevelsResponse = await Actions.callRest(context, {
              endpoint: 'getall_commonLookup_Codes/getall_commonLookups-lookupCodes',
              uriParams: {
                'commonLookups_Id': $application.constants.managerLevelLkupType,
                q: "LookupCode='" + jobTitleResponse.body.items[0]?.ManagerLevel + "'"
              },

            });

            $variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].ManagerLevel = managerLevelsResponse.body.items[0]?.Meaning;
            
            /*if ($variables.firstExecution === false) {
              $variables.xxreqJobReqRequests.jobLevelId = managerLevelsResponse.body.items[0]?.LookupCode;
            }*/
          }
        }

        $variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].LocationName = undefined;

        if ($variables.workerDetails.data[0]?.workRelationships.items[0]?.assignments.items[0]?.LocationId !== null) {


          const locationResponse = await Actions.callRest(context, {
            endpoint: 'getall_locations/getall_locations',
            uriParams: {
              q: "LocationId=" + $variables.workerDetails.data[0]?.workRelationships.items[0]?.assignments.items[0]?.LocationId
            },
          });

          $variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].LocationName = locationResponse.body.items[0]?.LocationName;
        }
        

        $variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].Salary = "";

        if ($variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].AssignmentId !== null) {

          const currentDateTimeVal = await $functions.getCurrentDateTime();
          //console.log(currentDateTimeVal.toString());

          const salaryResponse = await Actions.callRest(context, {
            endpoint: 'getall_salaries/getall_salaries',
            uriParams: {
              finder: "findByAssignmentIdAndDate;AssignmentId=" + $variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].AssignmentId.toString() + ",EffectiveDate=" + currentDateTimeVal.toString(),
              onlyData: 'true',
              fields: 'CurrencyCode,SalaryAmount',
            },
          });

          if (salaryResponse.body.items[0] !== null) {

            let currencyVal = salaryResponse.body.items[0]?.CurrencyCode !== null && salaryResponse.body.items[0]?.CurrencyCode !== undefined ? salaryResponse.body.items[0]?.CurrencyCode : "";
            let salaryVal = salaryResponse.body.items[0]?.SalaryAmount !== null && salaryResponse.body.items[0]?.SalaryAmount !== undefined ? $functions.convertSalaryToCurrency(salaryResponse.body.items[0]?.SalaryAmount,currencyVal !== "" ? currencyVal : "USD") : "";

            $variables.workerDetails.data[0].workRelationships.items[0].assignments.items[0].Salary = currencyVal + " " + salaryVal;
          }
        }

        if ($variables.workerDetails.data[0].workRelationships.items[0]?.assignments.items[0]?.assignmentsDFF.items[0]?.division !== null) {
          const divisionResponse = await Actions.callRest(context, {
            endpoint: 'getall_valueSetsValues/getall_valueSets-values',
            uriParams: {
              valueSets_Id: $application.constants.divisionValueSetCode,
              q: "Value='" + $variables.workerDetails.data[0].workRelationships.items[0]?.assignments.items[0]?.assignmentsDFF.items[0]?.division + "'",
              onlyData: 'true',
              fields: 'ValueId'
            }
          });
          if ($variables.firstExecution === false) {
            $variables.xxreqJobReqRequests.divisionId = divisionResponse.body.items[0]?.ValueId;
          }

        }

        if ($variables.workerDetails.data[0].workRelationships.items[0]?.assignments.items[0]?.DepartmentId !== null) {

          const engineeringDeptResponse = await Actions.callRest(context, {
            endpoint: 'businessObjects/getall_XxreqJobReqEnginDepts',
            uriParams: {
              q: "oraDepartmentId=" + $variables.workerDetails.data[0].workRelationships.items[0]?.assignments.items[0]?.DepartmentId.toString() + " and activeFlag=1",
              onlyData: 'true',
              fields: 'engineeringDepartmentId'
            },
          });

          if (engineeringDeptResponse.body.items[0]?.engineeringDepartmentId !== null && engineeringDeptResponse.body.items[0]?.engineeringDepartmentId !== undefined) {

            if ($variables.workerDetails.data[0].workRelationships.items[0]?.assignments.items[0]?.assignmentsDFF.items[0]?.module !== null) {
              const divisionResponse = await Actions.callRest(context, {
                endpoint: 'getall_valueSetsValues/getall_valueSets-values',
                uriParams: {
                  valueSets_Id: $application.constants.moduleValueSetCode,
                  q: "Value='" + $variables.workerDetails.data[0].workRelationships.items[0]?.assignments.items[0]?.assignmentsDFF.items[0]?.module + "'",
                  onlyData: 'true',
                  fields: 'ValueId'
                }
              });
              if ($variables.firstExecution === false) {
                $variables.xxreqJobReqRequests.moduleId = divisionResponse.body.items[0]?.ValueId;
              }
            }

            if ($variables.workerDetails.data[0].workRelationships.items[0]?.assignments.items[0]?.assignmentsDFF.items[0]?.suite !== null) {
              const divisionResponse = await Actions.callRest(context, {
                endpoint: 'getall_valueSetsValues/getall_valueSets-values',
                uriParams: {
                  valueSets_Id: $application.constants.suiteValueSetCode,
                  q: "Value='" + $variables.workerDetails.data[0].workRelationships.items[0]?.assignments.items[0]?.assignmentsDFF.items[0]?.suite + "'",
                  onlyData: 'true',
                  fields: 'ValueId'
                }
              });
              if ($variables.firstExecution === false) {
                $variables.xxreqJobReqRequests.suiteId = divisionResponse.body.items[0]?.ValueId;
              }
            }

            $variables.xxreqJobReqRequests.rdOrSupportFlag = true;



          } else {
            $variables.xxreqJobReqRequests.rdOrSupportFlag = false;
          }
        }



        //console.log("objWD" + $variables.workerDetails.data[0]?.PersonId);
        $variables.firstExecution = false;

        $variables.expandEmployeePanel = true;
      }
    }
  }

  return employeeSelectValueItemChange;
});
