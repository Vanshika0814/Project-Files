define(["ojs/ojconverter-nativenumber"], (numberConverter) => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.disableSubmitBtnFlag = function (statusId) {
    console.log("stid=" + statusId);
    console.log("tYid=" + typeof statusId);
    let disableBtn = statusId === 1 ? false : true;
    return disableBtn;
  };

  PageModule.prototype.readOnlySubmitBtnFlag = function (statusId) {
    console.log("stid=" + statusId);
    let readOnlyBtn = statusId === 1 ? false : true;
    return readOnlyBtn;
  };

  PageModule.prototype.getCurrentDateTime = function () {
    let date = new Date(Date.now());
    let dateF = date.toISOString();
    return dateF;
  };

  PageModule.prototype.convertSalaryToCurrency = function (amount, currency) {
    let numAmount = Number(amount);
    let numberConvertor = new numberConverter.NumberConverter({
      maximumFractionDigits: 2,
      useGrouping: true,
      currency: currency,
      currencyDisplay: "symbol",
      style: "currency",
    });

    return numberConvertor.format(numAmount);
  };

  PageModule.prototype.mergeDepartmentsData = function (organizations, parentDepartments) {
    if (!organizations.body.items || organizations.body.items.length === 0) {
      return [];
    }

    const parentDepartmentMap = new Map(
      parentDepartments?.items?.map(parentDept => [parentDept.Value, parentDept.Description])
    );

    const orgItems = organizations?.body?.items?.map(org => {

      const parentDeptName = parentDepartmentMap.get(org.OrganizationDFF.items[0].ksyGreenhouseParentid) || '';


      return {
        ...org,
        ParentDepartment: parentDeptName,

      };
    });
    organizations.body.items = orgItems;
    return organizations;
  };

  PageModule.prototype.validateGHFieldValue = function (customFieldsData, fieldNameKey, fieldValue) {

    //search field object
    const fieldItem = customFieldsData.find(field => field.name_key === fieldNameKey);
    //search value in custom options array
    const containsObject = fieldItem.custom_field_options.some((item) => (item.name === fieldValue || item.id === fieldValue));

    return containsObject;

  };





  return PageModule;
});
