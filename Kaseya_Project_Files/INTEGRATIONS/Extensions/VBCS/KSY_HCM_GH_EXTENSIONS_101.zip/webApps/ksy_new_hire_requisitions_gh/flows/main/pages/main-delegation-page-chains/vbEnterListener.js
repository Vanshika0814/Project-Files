define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'getall_publicWorkers_emp/getUserAccountRoles',
        responseBodyFormat: 'json',
        uriParams: {
          limit: '500',
        },
      });

      const filterLineManagers = await $functions.filterLineManagers(response.body.items);

      const q = await $functions.buildWorkerQuery(filterLineManagers);

      const response2 = await Actions.callRest(context, {
        endpoint: 'getall_publicWorkers_emp/getall_publicWorkers',
        uriParams: {
          q: q,
        },
        responseBodyFormat: 'json',
        headers: {
          'REST-Framework-Version': '2',
        },
      });

      

      
      const mergeManagerData = await $functions.mergeManagerData(filterLineManagers, response2.body.items);

      $variables.resultQ = q;

      $variables.listManagers = mergeManagerData;
    }
  }

  return vbEnterListener;
});
