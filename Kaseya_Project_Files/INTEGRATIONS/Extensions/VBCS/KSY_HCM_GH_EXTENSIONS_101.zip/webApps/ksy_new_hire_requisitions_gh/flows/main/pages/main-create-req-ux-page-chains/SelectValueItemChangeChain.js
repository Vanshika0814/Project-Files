define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any} params.key
     * @param {any} params.data
     * @param {any} params.metadata
     * @param {any} params.valueItem
     */
    async run(context, { event, previousValue, value, updatedFrom, key, data, metadata, valueItem }) {
      const { $page, $flow, $application, $constants, $variables } = context;



      if (data.Country != 'US') {
        $page.variables.disabledLocalCurrency = false;

        //GET Currency Code
        const response = await Actions.callRest(context, {
          endpoint: 'getCurrencies/getall_currenciesLOV',
          uriParams: {
            onlyData: true,
            q: "EnabledFlag='Y';IssuingTerritoryCode='" + data.Country + "'",
          },
          headers: {
            'REST-Framework-Version': '1',
          },
        });
        $page.variables.xxreqJobReqRequests.currency = response.body.items[0].CurrencyCode;

        //GET Conversion rate from today
        const today = new Date().toISOString().split('T')[0];
        const responseConversion = await Actions.callRest(context, {
          endpoint: 'getConversionRates/getall_currencyRates',
          uriParams: {
            onlyData: true,
            finder: 'CurrencyRatesFinder;fromCurrency=USD,toCurrency=' + response.body.items[0].CurrencyCode + ',userConversionType=Corporate,startDate=' + today + ',endDate=' + today,
          },
        });
        $page.variables.xxreqJobReqRequests.conversionRate = responseConversion.body.items[0].ConversionRate;

        


      } else {
        console.log(data.Country);
        $page.variables.disabledLocalCurrency = true;
        $page.variables.xxreqJobReqRequests.conversionRate = 0;
        $page.variables.xxreqJobReqRequests.salaryBaseLocal = null;
        $page.variables.xxreqJobReqRequests.variableSalaryLocal = null;
        $page.variables.xxreqJobReqRequests.currency = null;
      }
    }
  }

  return SelectValueItemChangeChain;
});
