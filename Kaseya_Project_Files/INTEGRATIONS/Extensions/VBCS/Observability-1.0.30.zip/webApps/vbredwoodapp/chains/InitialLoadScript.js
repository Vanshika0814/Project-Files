define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class InitialLoadScript extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $application, $constants, $variables } = context;

      $variables.downloadbaseurl = 'https://kaseya-ibwgjb-dev1.fa.ocs.oraclecloud.com/';

      // ---- TODO: Add your code here ---- //
      let getusername = $application.user.fullName;
      let getname = getusername.split(" ");
      $variables.ProfileNameShort = getname[0].charAt(0) + getname[1].charAt(0);
      $variables.firstname = getname[0];
      function updateclock() {
        const date = new Date();
        const formatter = new Intl.DateTimeFormat('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        });

      }
    function getOffsetString(date) {
        const offset = -date.getTimezoneOffset(); // invert sign
        const sign = offset >= 0 ? '+' : '-';
        const absOffset = Math.abs(offset);
        const hours = String(Math.floor(absOffset / 60)).padStart(2, '0');
        const minutes = String(absOffset % 60).padStart(2, '0');
        return `${sign}${hours}:${minutes}`;
      }


     function formatLocalDateTime(dateInput) {
        const date = new Date(dateInput); // Convert ISO string or Date object
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        return `${year}-${month}-${day}`;
      }
      const date1 = new Date();
      const formatter = new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
      $variables.StaticCurrentDateTime = formatter.format(date1);
   //   const myInterval = setInterval(() => {
        const datetime = updateclock();
        $variables.currentdatetime = formatter.format(datetime);
      //  document.getElementsByClassName("datandtime")[0].innerHTML = formatter.format(datetime);
     // }, 1000);



      // $variables.currentdatetime = setInterval(updateclock(), 1000);

    }
  }

  return InitialLoadScript;
});
