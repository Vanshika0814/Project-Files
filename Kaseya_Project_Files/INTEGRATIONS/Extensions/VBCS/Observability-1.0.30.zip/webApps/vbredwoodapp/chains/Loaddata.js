define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Loaddata extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_XxoodOicAuditlogsV',
      });

      $variables.OICLogsADP = response.body;

      
      
    }
  }

  return Loaddata;
});
