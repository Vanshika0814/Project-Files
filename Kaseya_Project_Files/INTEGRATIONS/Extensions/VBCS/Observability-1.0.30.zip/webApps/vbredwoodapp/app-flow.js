/* Copyright (c) 2024, Oracle and/or its affiliates */

define(['oj-sp/spectra-shell/config/config'], function() {
  'use strict';

  class AppModule {
  getformatDateWithOffset(getdate) {
    let date = new Date(getdate);
   const dateTime = date.toLocaleString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  }).replace(",", "");

  // Extract dynamic offset name (IST, EST, GMT, etc.)
  const offsetName = date.toLocaleString("en-US", { timeZoneName: "short" })
    .split(" ")
    .pop();

  return `${dateTime} (${offsetName})`;
}
     newformatDate(dateValue) {
      let getdate = dateValue.split(" ");
         //console.log(getdate[0]);
         const parts = getdate[0].split("-");
      const months =parts[0]; // months are 0-based
const days = parts[1];
const years =parts[2];
        let utcdate =  years+'-'+months+'-'+days+'T'+getdate[1]+"Z";
        //console.log(utcdate);
            if (dateValue) {
                const date = new Date(utcdate);
              
            //   const options = { year: 'numeric', month: 'long', day: 'numeric' , hour: '2-digit',  minute: '2-digit', second: '2-digit'};
              //  return date.toDateString(undefined, options); // Formats as "Month Day, Year"
              return date.toLocaleString();
            }
            return '';
        };  
  toISOWithOffset(date) {
    const tzo = -date.getTimezoneOffset(),
      dif = tzo >= 0 ? '+' : '-',
      pad = function (num) {
        const norm = Math.floor(Math.abs(num));
        return (norm < 10 ? '0' : '') + norm;
      };
    return date.getFullYear() +
      '-' + pad(date.getMonth() + 1) +
      '-' + pad(date.getDate()) +
      'T' + pad(date.getHours()) +
      ':' + pad(date.getMinutes()) +
      ':' + pad(date.getSeconds()) +
      dif + pad(tzo / 60) +
      ':' + pad(tzo % 60);
  }


    getOffsetString(date) {
        const offset = -date.getTimezoneOffset(); // invert sign
        const sign = offset >= 0 ? '+' : '-';
        const absOffset = Math.abs(offset);
        const hours = String(Math.floor(absOffset / 60)).padStart(2, '0');
        const minutes = String(absOffset % 60).padStart(2, '0');
        return `${sign}${hours}:${minutes}`;
      }


      formatLocalDateTime(dateInput) {
        const date = new Date(dateInput); // Convert ISO string or Date object
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        return `${year}-${month}-${day}`;
      }

  formatDate(dateValue) {
            if (dateValue) {
                const date = new Date(dateValue);
            //   const options = { year: 'numeric', month: 'long', day: 'numeric' , hour: '2-digit',  minute: '2-digit', second: '2-digit'};
              //  return date.toDateString(undefined, options); // Formats as "Month Day, Year"
              return date.toLocaleString();
            }
            return '';
        };  
       formatDateWithOffset(date) {
  // Get timezone offset in minutes
  const offsetMinutes = date.getTimezoneOffset();
  const offsetHours = Math.floor(Math.abs(offsetMinutes) / 60);
  const offsetMins = Math.abs(offsetMinutes) % 60;
  const sign = offsetMinutes <= 0 ? "+" : "-";

  // Format YYYY-MM-DDTHH:mm:ss±HH:MM
  const pad = n => String(n).padStart(2, "0");
  return (
    date.getFullYear() + "-" +
    pad(date.getMonth() + 1) + "-" +
    pad(date.getDate()) + "T" +
    pad(date.getHours()) + ":" +
    pad(date.getMinutes()) + ":" +
    pad(date.getSeconds()) +
    sign + pad(offsetHours) + ":" + pad(offsetMins)
  );
}
  }

  return AppModule;
});
