window.onload = function() {
 alert("load");
};