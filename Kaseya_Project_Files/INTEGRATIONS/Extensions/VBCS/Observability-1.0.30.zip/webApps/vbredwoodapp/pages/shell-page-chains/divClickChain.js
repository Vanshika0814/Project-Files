define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class divClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await this.SideboarHideShow(context);
    }

    /**
     * @param {Object} context
     */
    async SideboarHideShow(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
    alert("testedhi");
  //  querySelectorAll("k-ob-sidebar");
    // Select the element with the ID 'myDiv'
//const element = document.querySelector('.k-ob-sidebar'); // Or getElementById('myDiv')

// Add the class 'newClass' to the element
//element.classList.toggle('newClass');
let yourUl = document.getElementById('k-ob-sidebar');
      yourUl.classList.toggle("sidebarhide");
    }
  }

  return divClickChain;
});
