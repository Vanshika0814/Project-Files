define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraydataprovider'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayDataProvider
) => {
  'use strict';

  class ComboValueChangeChain extends ActionChain {


 getOffsetString(date) {
  const offset = -date.getTimezoneOffset(); // invert sign
  const sign = offset >= 0 ? '+' : '-';
  const absOffset = Math.abs(offset);
  const hours = String(Math.floor(absOffset / 60)).padStart(2, '0');
  const minutes = String(absOffset % 60).padStart(2, '0');
  return `${sign}${hours}:${minutes}`;
}


formatLocalDateTime(dateInput) {
  const date = new Date(dateInput); // Convert ISO string or Date object
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
return `${year}-${month}-${day}`;
}



    toISOWithOffset(date) {
      const tzo = -date.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function (num) {
          const norm = Math.floor(Math.abs(num));
          return (norm < 10 ? '0' : '') + norm;
        };
      return date.getFullYear() +
        '-' + pad(date.getMonth() + 1) +
        '-' + pad(date.getDate()) +
        'T' + pad(date.getHours()) +
        ':' + pad(date.getMinutes()) +
        ':' + pad(date.getSeconds()) +
        dif + pad(tzo / 60) +
        ':' + pad(tzo % 60);
    }



    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value
     */
    async run(context, { value }) {
      const { $fragment, $application, $constants, $variables, $functions } = context;
  
         const getDate = new Date();
      let getTodayDate = $application.functions.formatLocalDateTime(getDate) + "T00:00:00" + $application.functions.getOffsetString(getDate);

      const res = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_ReportLastRunDetailsV',
      });

      $variables.OCISummaryPostData.lastSuccessRun = $application.functions.formatLocalDateTime(res.body.items[0].successfullRunTime);
      $variables.OCISummaryPostData.triggerType = "Detail";

  const now = new Date(); // end date is always today
  let startDate;
      if (res.body.items[0].isOlderThan3Min === "Y") {
        const res2 = await Actions.callRest(context, {
          endpoint: 'essbiccdetail/postIcApiIntegrationV2FlowsRestProjectCOMMONKSY_XXI021_ESS_BICC_DTL1_0Essbiccdetail',
          body: JSON.stringify($variables.OCISummaryPostData),
        });
      }


      $application.variables.selectdaterange = value;
      
      let popup = document.getElementById("loading-dialog");

      let daycount = "0";
      let int_type;
      if (value === "1") {
        daycount = "0";
           startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);

      } else if (value === "2") {
        daycount = "1";
       startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 0, 0, 0);
       let yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 23, 59, 59);
        $application.variables.filtertodate =$application.functions.formatDateWithOffset(yesterday);
      }
      else if (value === "3") {
        daycount = "6";
       startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7, 0, 0, 0);
      }
      else if (value === "4") {
        daycount = "30";
        const lastMonthStart = new Date();
            startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 30, 0, 0, 0);
      }

  $application.variables.filterfromdate = $application.functions.formatDateWithOffset(startDate);
  if (value !== "2") {
  $application.variables.filtertodate =  $application.functions.formatDateWithOffset(now);
  }

  console.log('New Local Time');
 console.log($application.variables.filterfromdate);
 console.log($application.variables.filtertodate);
      if ($application.currentPage.id === "oic-dashboard-start") {
        int_type = "OIC";
      } else if ($application.currentPage.id === "ess-dashboard-start") {
        int_type = "ESS";
      } else if ($application.currentPage.id === "bicc-dashboard-start") {
        int_type = "BICC";
      }

      if (!popup.isOpen()) {
        popup.open();
      }
      const essresult = await Actions.callRest(context, {
        endpoint: 'getSummaryServ/getDbGetSummary',
        uriParams: {
          'p_days_cnt': daycount,
          'p_job_type': int_type,
          'p_current_time':getTodayDate
        },
      });
      if (essresult.ok) {
        popup.close();
      }

      let essres = essresult.body.items[0]['xxood_xxi021_job_summary_pkg.ess_summary_fnc(:1,:2,:3)'];
      let getval = essres.split(":");
      let succount, cancount, errcount, waitcount, finishcount, warningcount, totalcount, inprogresscount;
      if ($application.currentPage.id === "ess-dashboard-start" || $application.currentPage.id === "bicc-dashboard-start") {
        succount = getval[1].split("-");
        cancount = getval[2].split("-");
        errcount = getval[3].split("-");
        waitcount = getval[4].split("-");
        finishcount = getval[5].split("-");
        warningcount = getval[6].split("-");
        $application.variables.getchartdata = [
          { "recordCount": cancount[1], "statusType": "Cancelled", "series": int_type },
          { "recordCount": errcount[1], "statusType": "Error", "series": int_type },
          { "recordCount": finishcount[1], "statusType": "Finished", "series": int_type },
          { "recordCount": succount[1], "statusType": "Success", "series": int_type },
          { "recordCount": waitcount[1], "statusType": "Wait", "series": int_type },
          { "recordCount": warningcount[1], "statusType": "Warning", "series": int_type }
        ];
      } else {

        totalcount = getval[0].split("-");
        succount = getval[1].split("-");
        errcount = getval[2].split("-");
        inprogresscount = getval[3].split("-");
        $application.variables.getchartdata = [
          { "recordCount": errcount[1], "statusType": "Error", "series": "OIC" },
          { "recordCount": succount[1], "statusType": "Success", "series": "OIC" },
          { "recordCount": inprogresscount[1], "statusType": "Inprogress", "series": "OIC" }
        ];
      }

      $application.variables.getsummarychart =
        new ArrayDataProvider($application.variables.getchartdata, { keyAttributes: 'statusType' });
      if ($application.currentPage.id === "ess-dashboard-start") {
        $application.variables.esserrorcount = errcount[1];
        $application.variables.esscancelledcount = cancount[1];
        $application.variables.esssuccesscount = succount[1];
        $application.variables.esswaitcount = waitcount[1];
        $application.variables.esswarning = warningcount[1];
        $application.variables.essfinishedcount = finishcount[1];
      } else if ($application.currentPage.id === "bicc-dashboard-start") {

        $application.variables.biccerrorcount = errcount[1];
        $application.variables.bicccancelledcount = cancount[1];
        $application.variables.biccsuccesscount = succount[1];
        $application.variables.biccwaitcount = waitcount[1];
        $application.variables.biccwarningcount = warningcount[1];
        $application.variables.biccfinishedcount = finishcount[1];
      } else if ($application.currentPage.id === "oic-dashboard-start") {

        $application.variables.ActiveIntegration = inprogresscount[1];
        $application.variables.Errorcount = errcount[1];
        $application.variables.success = succount[1];
        $application.variables.InstanceCount = totalcount[1];
      }
      if (essresult.ok) {
        popup.close();
      }




    }
  }

  return ComboValueChangeChain;
});