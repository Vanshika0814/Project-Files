define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class IconClickChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // ---- TODO: Add your code here ---- //
      
     //  navigator.clipboard.writeText($variables.errorsummary);
       // Get a reference to the div element
const myDiv = document.getElementById('summarycopy');
 const tempInput = document.createElement("textarea");
  tempInput.value = $variables.errorsummary;
  
  // Append the element to the document
  document.body.appendChild(tempInput);
  
  // Select the text within the temporary input
  tempInput.select();

  document.execCommand('copy'); // To copy the selected text


// Function to show the div
function showDiv() {
  myDiv.style.display = 'block'; // Or 'flex', 'grid', etc., depending on your layout
}

// Function to hide the div
function hideDiv() {
  myDiv.style.display = 'none';
}

// Call showDiv to make it visible
showDiv();

// Set a timeout to call hideDiv after 5000 milliseconds (5 seconds)
setTimeout(hideDiv, 5000);
    }
  }

  return IconClickChain;
});
