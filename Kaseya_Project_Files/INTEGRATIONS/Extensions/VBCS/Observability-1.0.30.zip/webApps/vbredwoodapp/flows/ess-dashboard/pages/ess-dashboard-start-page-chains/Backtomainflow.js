define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Backtomainflow extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const toSaas = await Actions.navigateToFlow(context, {
        target: 'parent',
        flow: 'saas',
        page: 'saas-start',
      });
    }
  }

  return Backtomainflow;
});
