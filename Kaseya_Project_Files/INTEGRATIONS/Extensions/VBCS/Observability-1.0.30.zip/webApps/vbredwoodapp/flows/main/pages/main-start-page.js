define([], () => {
  'use strict';

  class PageModule {

    isAllowed(id, role) {
      console.log("idd: " + id + " rrole:" + role);
      if ((id === 'saas' && role.SaaS) || (id === 'paas' && role.PaaS) || (id === 'iaas' && role.IaaS)) {
        return true;
      } else {
        return false;
      }
    }

    imagetilsloaded(){
      const tils1 = document.getElementsByClassName('inttype-tiles')[0];
    const tils2 = document.getElementsByClassName('inttype-tiles')[1];
    const tils3 = document.getElementsByClassName('inttype-tiles')[2];
// Add a class initially (for demonstration)
//myElement.classList.add('my-class');

// Set a timeout to remove the class after 3 seconds (3000 milliseconds)
setTimeout(function() {
    tils1.classList.remove('tilsloader');
    tils2.classList.remove('tilsloader');
    tils3.classList.remove('tilsloader');
 
  //console.log('Class "my-class" removed!');
}, 1000);
    }

  }

  return PageModule;
});
