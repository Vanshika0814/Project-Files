define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {
    formatDate(dateValue) {
      if (dateValue) {
        const date = new Date(dateValue);
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return date.toLocaleDateString(undefined, options); // Formats as "Month Day, Year"
      }
      return '';
    };
    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      $variables.filters[1].value = $application.variables.biccstatusfilter;
      if ($application.variables.selectdaterange === "1" && $application.variables.filterfromdate === undefined) {
        //console.log("contentllooading");
     //   const today = new Date();
         const currentDate = new Date();
          const year = currentDate.getFullYear();
    const month = currentDate.getMonth() + 1; // Month is 0-indexed (January is 0)
    const day = currentDate.getDate().toLocaleString('en-US', { minimumIntegerDigits: 2 });
        const startToday =  year+'-'+month+'-'+day+ "T00:00:00";
       // const nextday = new Date();
        //nextday.setDate(nextday.getDate());
        const endToday =  year+'-'+month+'-'+day+ "T23:59:59";
        $variables.filters[3].value =    startToday;
         $variables.filters[4].value =endToday;
        $application.variables.filterfromdate = startToday;
        $application.variables.filtertodate = endToday;
      } else {
        $variables.filters[3].value = $application.variables.filterfromdate;
        $variables.filters[4].value = $application.variables.filtertodate;
      }

    }
  }

  return vbEnterListener;
});
