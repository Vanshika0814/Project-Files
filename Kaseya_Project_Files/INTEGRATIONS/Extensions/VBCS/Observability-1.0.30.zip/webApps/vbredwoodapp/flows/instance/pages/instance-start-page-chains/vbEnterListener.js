define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  "ojs/ojconverter-number", 
  "ojs/ojconverter-datetime",
], (
  ActionChain,
  Actions,
  ActionUtils,
  datetimeConverter
) => {
  'use strict';

  class vbEnterListener extends ActionChain {
    formatDate(dateValue) {
      if (dateValue) {
        const date = new Date(dateValue);
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return date.c(undefined, options);
        //return date.toLocaleDateString(undefined, options); // Formats as "Month Day, Year"
      }
      return '';
    };
    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      $variables.filters[1].value = $application.variables.oicfilterstatus;
    
      if ($application.variables.selectdaterange === "1" && ($application.variables.filterfromdate === undefined || $application.variables.filterfromdate ==="")) {
 const now = new Date(); // end date is always today
 let startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
 let endToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);

        $variables.filters[5].value =$application.functions.formatDateWithOffset(startToday);
        $variables.filters[6].value = $application.functions.formatDateWithOffset(endToday);
        $application.variables.filterfromdate =$application.functions.formatDateWithOffset(startToday);
        $application.variables.filtertodate = $application.functions.formatDateWithOffset(endToday);
      } else {
        console.log("getdatess");
        console.log($application.variables.filterfromdate);
          console.log($application.variables.filtertodate);
        $variables.filters[5].value = $application.variables.filterfromdate;
        $variables.filters[6].value = $application.variables.filtertodate;
      }

    }
  }

  return vbEnterListener;
});
