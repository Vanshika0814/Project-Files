define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraydataprovider'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayDataProvider
) => {
  'use strict';

  class BiccDashboarddataCount extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $application.variables.selectdaterange = "1";
      let popup = document.getElementById("loading-dialog");
      if (!popup.isOpen()) {
        popup.open();
      }
      const response3 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_ReportLastRunDetailsV',


      });

      //$variables.OCISummaryPostData.lastSuccessRun = response3.body.items[0].successfullRunTime;
      $variables.OCISummaryPostData.lastSuccessRun = $application.functions.newformatDate(response3.body.items[0].successfullRunTime);
     // $application.variables.lastSuccessRun = response3.body.items[0].successfullRunTime;
     $application.variables.lastSuccessRun = $application.functions.newformatDate(response3.body.items[0].successfullRunTime);
      $variables.OCISummaryPostData.triggerType = "Detail";


      if (response3.body.items[0].isOlderThan3Min === "Y") {
        const response2 = await Actions.callRest(context, {
          endpoint: 'essbiccdetail/postIcApiIntegrationV2FlowsRestProjectCOMMONKSY_XXI021_ESS_BICC_DTL1_0Essbiccdetail',
          body: JSON.stringify($variables.OCISummaryPostData),
        });
        if (response2.ok) {
          popup.close();
        }
      }
 const getDate = new Date();
      let getTodayDate = $application.functions.formatLocalDateTime(getDate) + "T00:00:00" + $application.functions.getOffsetString(getDate);

      const essresult = await Actions.callRest(context, {
        endpoint: 'getSummaryServ/getDbGetSummary',
        uriParams: {
          'p_days_cnt': '0',
          'p_job_type': 'BICC',
           'p_current_time': getTodayDate
        },
      });
      let essres = essresult.body.items[0]['xxood_xxi021_job_summary_pkg.ess_summary_fnc(:1,:2,:3)'];
      let getval = essres.split(":");
      let succount = getval[1].split("-");
      let cancount = getval[2].split("-");
      let errcount = getval[3].split("-");
      let waitcount = getval[4].split("-");
      let finishcount = getval[5].split("-");
      let warningcount = getval[6].split("-");
      $application.variables.getchartdata = [
        { "recordCount": cancount[1], "statusType": "Cancelled", "series": "BICC" },
        { "recordCount": errcount[1], "statusType": "Error", "series": "BICC" },
        { "recordCount": finishcount[1], "statusType": "Finished", "series": "BICC" },
        { "recordCount": succount[1], "statusType": "Success", "series": "BICC" },
        { "recordCount": waitcount[1], "statusType": "Wait", "series": "BICC" },
        { "recordCount": warningcount[1], "statusType": "Warning", "series": "BICC" }
      ];

      $application.variables.getsummarychart =
        new ArrayDataProvider($application.variables.getchartdata, { keyAttributes: 'statusType' });

      /* const response = await Actions.callRest(context, {
         endpoint: 'businessObjects/getall_BiccCountTodayV',
       });*/
      $application.variables.biccerrorcount = errcount[1];
      $application.variables.bicccancelledcount = cancount[1];
      $application.variables.biccsuccesscount = succount[1];
      $application.variables.biccwaitcount = waitcount[1];
      $application.variables.biccwarningcount = warningcount[1];
      $application.variables.biccfinishedcount = finishcount[1];
      if (essresult.ok) {
        popup.close();
      }
    }

  }

  return BiccDashboarddataCount;
});
