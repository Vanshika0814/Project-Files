define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CardActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
        
 const response3 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_ReportLastRunDetailsV',

        
      });
     
      $variables.OCISummaryPostData.lastSuccessRun = response3.body.items[0].successfullRunTime;
     $application.variables.lastSuccessRun =  response3.body.items[0].successfullRunTime;
       $variables.OCISummaryPostData.triggerType = "Detail";
     
      
      if(response3.body.items[0].isOlderThan3Min === "Y")
      {

        const response2 = await Actions.callRest(context, {
          endpoint: 'essbiccdetail/postIcApiIntegrationV2FlowsRestProjectCOMMONKSY_XXI021_ESS_BICC_DTL1_0Essbiccdetail',
          body: JSON.stringify($variables.OCISummaryPostData),
        });
  
      }

      $application.variables.biccstatusfilter = 'Error';

      const toBiccjobsLogsList = await Actions.navigateToFlow(context, {
        target: 'parent',
        flow: 'biccjobs-logs-list',
        page: 'biccjobs-logs-list-start',
      });
    }
  }

  return CardActionChain1;
});
