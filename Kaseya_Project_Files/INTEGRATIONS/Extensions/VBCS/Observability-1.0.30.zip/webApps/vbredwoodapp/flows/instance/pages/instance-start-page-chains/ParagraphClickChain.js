define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ParagraphClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $current } = context;
      $variables.errorsummary = current.data;
      let popup = document.getElementById("summary");
    //  popup.select();
  //popup.setSelectionRange(0, 99999); // For mobile devices

   // Copy the text inside the text field
  //navigator.clipboard.writeText(current.data);
       if (!popup.isOpen()) {
            popup.open();
          }
    }
  }

  return ParagraphClickChain;
});
