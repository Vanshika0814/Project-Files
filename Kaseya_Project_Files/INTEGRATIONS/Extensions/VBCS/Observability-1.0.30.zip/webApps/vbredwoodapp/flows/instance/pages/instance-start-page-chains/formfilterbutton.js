define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class formfilterbutton extends ActionChain {
    toISOWithOffset(date) {
      const tzo = -date.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function (num) {
          const norm = Math.floor(Math.abs(num));
          return (norm < 10 ? '0' : '') + norm;
        };
      return date.getFullYear() +
        '-' + pad(date.getMonth() + 1) +
        '-' + pad(date.getDate()) +
        'T' + pad(date.getHours()) +
        ':' + pad(date.getMinutes()) +
        ':' + pad(date.getSeconds()) +
        dif + pad(tzo / 60) +
        ':' + pad(tzo % 60);
    }
    formatDate(dateValue) {
      if (dateValue) {
        const date = new Date(dateValue);
        //return "hi";
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        // return date.toLocaleTimeString(undefined, options);
        return date.toISOString(undefined, options); // Formats as "Month Day, Year"
        //return date.getMonth();
      }
      return '';
    };
    formattoDate(dateValue) {
      if (dateValue) {
        const date = new Date(dateValue);
        const endate = new Date(date.setHours(23, 59, 0, 0));
        //return "hi";
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        // return date.toLocaleTimeString(undefined, options);
        // console.log(endate.toISOString(undefined, options));
        return endate.toISOString(undefined, options); // Formats as "Month Day, Year"
        //return date.getMonth();
      }
      return '';
    };
    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($variables.formprocessid !== null || $variables.formprocessid !== 'undefined') {
        $variables.filters[0].value = $variables.formprocessid;
      }
      if ($variables.formstatus !== null || $variables.formstatus !== 'undefined') {
        $variables.filters[1].value = $application.variables.oicfilterstatus;
      }
      if ($variables.formtrack !== null || $variables.formtrack !== 'undefined') {
        $variables.filters[2].value = $variables.formtrack;
      }
      if ($variables.formintegrationname !== null || $variables.formintegrationname !== 'undefined') {
        $variables.filters[3].value = $variables.formintegrationname;
      }
      if ($variables.forminvokedby !== null || $variables.forminvokedby !== 'undefined') {
        $variables.filters[4].value = $variables.forminvokedby;
      }

      const getstartdate = $application.variables.filterfromdate;
    //  const getonlydate = getstartdate.split("T");

      if ($application.variables.filterfromdate !== undefined) {

        $variables.filters[5].value =$application.variables.filterfromdate;
       // $variables.filters[5].value = getonlydate[0] + "T00:00:00";
        // $variables.filters[5].value = $application.variables.filterfromdate;
         //$variables.filters[5].value = this.formatDate($application.variables.filterfromdate);
      }
      if ($application.variables.filtertodate !== undefined) {
        const getdate1 = new Date($application.variables.filtertodate);
        //const getdate1 =this.formattoDate($application.variables.filtertodate);
        //const getdate1 = $application.variables.filtertodate;

        //const getonlydate1 = getdate1.split("T");
       // $variables.filters[6].value = getonlydate1[0] + "T23:59:59";
         $variables.filters[6].value =  $application.variables.filtertodate;
      }


      const getcount = $variables.xxoodOicAuditlogsVListSDP.uriParameters.totalResults;

    }
  }
  return formfilterbutton;
});
