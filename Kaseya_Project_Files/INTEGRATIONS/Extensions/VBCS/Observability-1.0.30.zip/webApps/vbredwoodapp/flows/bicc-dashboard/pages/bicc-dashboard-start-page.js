define([], () => {
  'use strict';

  class PageModule {

  convertDecimalToInt(decimalValue) {
      return Math.floor(decimalValue);
    }
  }
  
  return PageModule;
});
