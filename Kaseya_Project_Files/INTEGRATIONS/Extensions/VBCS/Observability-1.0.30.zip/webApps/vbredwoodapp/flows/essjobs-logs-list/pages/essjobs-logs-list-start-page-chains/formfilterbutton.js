define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class formfilterbutton extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
     if ($variables.requestid !== null || $variables.requestid !== 'undefined') {
        $variables.filters[0].value = $variables.requestid;
      }
      if ($application.variables.Essfilterstatus !== null || $application.variables.Essfilterstatus !== 'undefined') {
        $variables.filters[1].value = $application.variables.Essfilterstatus;
      }
      if ($variables.name !== null || $variables.name !== 'undefined') {
        $variables.filters[2].value = $variables.name;
      }
      if ($application.variables.filterfromdate !== undefined) {
       
     
        $variables.filters[3].value = $application.variables.filterfromdate;
       
      }
      if ($application.variables.filtertodate !== undefined) {
      
        $variables.filters[4].value = $application.variables.filtertodate;
        
      }
    }
  }

  return formfilterbutton;
});
