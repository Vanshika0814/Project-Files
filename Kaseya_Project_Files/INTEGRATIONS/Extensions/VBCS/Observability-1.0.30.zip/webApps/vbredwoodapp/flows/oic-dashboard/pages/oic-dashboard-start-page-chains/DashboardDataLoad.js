define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraydataprovider'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayDataProvider
) => {
  'use strict';

  class DashboardDataLoad extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
 $application.variables.selectdaterange  = "1";
  const getDate = new Date();
      let getTodayDate = $application.functions.formatLocalDateTime(getDate) + "T00:00:00" + $application.functions.getOffsetString(getDate);

   const essresult = await Actions.callRest(context, {
        endpoint: 'getSummaryServ/getDbGetSummary',
        uriParams: {
          'p_days_cnt': '0',
          'p_job_type': 'OIC',
           'p_current_time': getTodayDate
        },
      });
      let essres = essresult.body.items[0]['xxood_xxi021_job_summary_pkg.ess_summary_fnc(:1,:2,:3)'];
      
    let getval = essres.split(":");
    let totalcount= getval[0].split("-");
    let succount  = getval[1].split("-");
    let errcount =  getval[2].split("-");
    let inprogresscount =  getval[3].split("-");

    $application.variables.getchartdata = [
    { "recordCount": errcount[1], "statusType": "Error", "series": "OIC" },
    { "recordCount": succount[1], "statusType": "Success", "series": "OIC" },
    { "recordCount": inprogresscount[1], "statusType": "Inprogress", "series": "OIC" }
    ];

    $application.variables.getsummarychart =
    new ArrayDataProvider($application.variables.getchartdata, { keyAttributes: 'statusType' });

    $application.variables.ActiveIntegration = inprogresscount[1];
    $application.variables.Errorcount = errcount[1];
    $application.variables.success =succount[1];
    $application.variables.InstanceCount = totalcount[1];
    }
  }

  return DashboardDataLoad;
});
