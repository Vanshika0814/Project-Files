define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  "ojs/ojconverter-number", 
  "ojs/ojconverter-datetime",
], (
  ActionChain,
  Actions,
  ActionUtils,
  datetimeConverter
) => {
  'use strict';

  class vbEnterListener extends ActionChain {
    formatDate(dateValue) {
      if (dateValue) {
        const date = new Date(dateValue);
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return date.c(undefined, options);
        //return date.toLocaleDateString(undefined, options); // Formats as "Month Day, Year"
      }
      return '';
    };
    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      $variables.filters[1].value = $application.variables.oicfilterstatus;
      if ($application.variables.selectdaterange === "1" && ($application.variables.filterfromdate === undefined || $application.variables.filterfromdate ==="")) {
        //console.log("contentllooading");
        const today = new Date();
        const startToday = new Date(today.setHours(0, 0, 0, 0));
        const nextday = new Date();
        //nextday.setDate(nextday.getDate() + 1);
        nextday.setDate(nextday.getDate());
        const endToday = new Date(nextday.setHours(23, 59, 59, 999));
        $variables.filters[5].value = $functions.toISOWithOffset(startToday);
        $variables.filters[6].value = $functions.toISOWithOffset(endToday);
        $application.variables.filterfromdate = $functions.toISOWithOffset(startToday);
        $application.variables.filtertodate = $functions.toISOWithOffset(endToday);
      } else {
        console.log($application.variables.filterfromdate);
        $variables.filters[5].value = $application.variables.filterfromdate;
        $variables.filters[6].value = $application.variables.filtertodate;
      }

    }
  }

  return vbEnterListener;
});
