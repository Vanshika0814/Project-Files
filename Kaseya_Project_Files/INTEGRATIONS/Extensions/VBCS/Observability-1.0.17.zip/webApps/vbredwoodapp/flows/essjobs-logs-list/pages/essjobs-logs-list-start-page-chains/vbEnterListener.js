define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {
    formatDate(dateValue) {
      if (dateValue) {
        const date = new Date(dateValue);
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return date.toLocaleDateString(undefined, options); // Formats as "Month Day, Year"
      }
      return '';
    };
    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
 $variables.filters[1].value = $application.variables.Essfilterstatus;
      if ($application.variables.selectdaterange === "1" && $application.variables.filterfromdate === undefined) {
        //console.log("contentllooading");
        const today = new Date();
        const startToday = new Date(today.setHours(0, 0, 0, 0));
        const nextday = new Date();
        nextday.setDate(nextday.getDate() + 1);
        const endToday = new Date(nextday.setHours(23, 59, 59, 999));
        $variables.filters[3].value =    $functions.toISOWithOffset(startToday);
         $variables.filters[4].value = $functions.toISOWithOffset(endToday);
        $application.variables.filterfromdate = $functions.toISOWithOffset(startToday);
        $application.variables.filtertodate = $functions.toISOWithOffset(endToday);
      } else {
        $variables.filters[3].value = $application.variables.filterfromdate;
        $variables.filters[4].value = $application.variables.filtertodate;
      }

    }
  }

  return vbEnterListener;
});
