define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojconverter-datetime'
], (
  ActionChain,
  Actions,
  ActionUtils,
  datetimeConverter
) => {
  'use strict';

  class ComboValueChangeChain extends ActionChain {
    convertDateToStr(customDate) {
      console.log(customDate);
      let dateConvertor = new datetimeConverter.IntlDateTimeConverter({
        pattern: "MM/dd/yyyy",
      });
      console.log(dateConvertor);
      return dateConvertor.format(customDate);
    }



    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      $application.variables.selectdaterange = value;
      var nextday = new Date();
      nextday.setDate(nextday.getDate() + 1);
     // const endToday = new Date(nextday.setHours(23, 59, 59, 999));
      const endToday = new Date(nextday.setHours(0, 0, 0, 0));
      if (value === "1") {
        //today date filter
        const today = new Date();
        const startToday = new Date(today.setHours(0, 0, 0, 0));
        $application.variables.filterfromdate = $functions.toISOWithOffset(startToday);
        $application.variables.filtertodate = $functions.toISOWithOffset(endToday);
      }
      if (value === "2") {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const startYesterday = new Date(yesterday.setHours(0, 0, 0, 0));
        const endYesterday = new Date(yesterday.setHours(23, 59, 59, 999));
        $application.variables.filterfromdate = $functions.toISOWithOffset(startYesterday);
        $application.variables.filtertodate = $functions.toISOWithOffset(endToday);
      }
  if (value === "3") {
        const lastWeekStart = new Date();
        lastWeekStart.setDate(lastWeekStart.getDate() - lastWeekStart.getDay() - 7);
        const lastWeekEnd = new Date(lastWeekStart);
        lastWeekEnd.setDate(lastWeekEnd.getDate() + 6);
         $application.variables.filterfromdate = $functions.toISOWithOffset(lastWeekStart);
        $application.variables.filtertodate = $functions.toISOWithOffset(endToday);
  }
  if (value === "4") {
        const lastMonthStart = new Date();
        lastMonthStart.setDate(1);
        lastMonthStart.setMonth(lastMonthStart.getMonth() - 1);
        const lastMonthEnd = new Date(lastMonthStart.getFullYear(), lastMonthStart.getMonth() + 1, 0);
 $application.variables.filterfromdate = $functions.toISOWithOffset(lastMonthStart);
        $application.variables.filtertodate = $functions.toISOWithOffset(endToday);

      }
    }
  }

  return ComboValueChangeChain;
});
