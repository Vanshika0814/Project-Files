define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CardActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const response3 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_ReportLastRunDetailsV',

        
      });
      
      $variables.oicsummaryUpdateDate.lastSuccessRun = response3.body.items[0].successfullRunTime;
      $variables.oicsummaryUpdateDate.triggerType  = "Detail";
      if(response3.body.items[0].isOlderThan3Min === "Y")
      {
        const response2 = await Actions.callRest(context, {
              endpoint: 'essbiccsummary/postIcApiIntegrationV2FlowsRestProjectCOMMONKSY_XXI021_ESS_BICC_SUMMARY1_0Essbiccsummary',
        
              body: JSON.stringify($variables.oicsummaryUpdateDate),
            });

            console.log("OCI 1 Call");
       //console.log(response2.body);
        console.log(JSON.stringify(response2));
      }
      const toSaas = await Actions.navigateToFlow(context, {
        target: 'parent',
        flow: 'saas',
      });
    }
  }

  return CardActionChain1;
});
