/**
 * Copyright (c)2020, 2025, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 */
define(["ojs/ojconverter-number", "ojs/ojconverter-datetime"], function (
  NumberConverter
) {
  "use strict";

  class PageModule {
    constructor() {

    }
     toISOWithOffset(date) {
    const tzo = -date.getTimezoneOffset(),
      dif = tzo >= 0 ? '+' : '-',
      pad = function (num) {
        const norm = Math.floor(Math.abs(num));
        return (norm < 10 ? '0' : '') + norm;
      };
    return date.getFullYear() +
      '-' + pad(date.getMonth() + 1) +
      '-' + pad(date.getDate()) +
      'T' + pad(date.getHours()) +
      ':' + pad(date.getMinutes()) +
      ':' + pad(date.getSeconds()) +
      dif + pad(tzo / 60) +
      ':' + pad(tzo % 60);
  }
     formatDate(dateValue) {
            if (dateValue) {
                const date = new Date(dateValue);
                const options = { year: 'numeric', month: 'long', day: 'numeric' };
                return date.toLocaleDateString(undefined, options); // Formats as "Month Day, Year"
            }
            return '';
        };    
    mapToCriteria(filters) {
           const date1 = new Date();
      const formatter = new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
      let criteria = [];
      filters
        .filter((f) => {
          if (Array.isArray(f.value) && f.value.length > 0) {
            return true;
          } else if (typeof f.value === "string" && f.value) {
            return true;
          } else if (typeof f.value === "number" && f.value !== null) {
            return true;
          } else {
            return false;
          }
        })
        .forEach((f) => {
           criteria.push(f);
        });
      return criteria;
    }
  }

  return PageModule;
});
