define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraydataprovider'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayDataProvider
) => {
  'use strict';

  class ComboValueChangeChain extends ActionChain {
    toISOWithOffset(date) {
      const tzo = -date.getTimezoneOffset(),
        dif = tzo >= 0 ? '+' : '-',
        pad = function (num) {
          const norm = Math.floor(Math.abs(num));
          return (norm < 10 ? '0' : '') + norm;
        };
      return date.getFullYear() +
        '-' + pad(date.getMonth() + 1) +
        '-' + pad(date.getDate()) +
        'T' + pad(date.getHours()) +
        ':' + pad(date.getMinutes()) +
        ':' + pad(date.getSeconds()) +
        dif + pad(tzo / 60) +
        ':' + pad(tzo % 60);
    }
    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value
     */
    async run(context, { value }) {
      const { $fragment, $application, $constants, $variables, $functions } = context;


      const res = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_ReportLastRunDetailsV',
      });

      $variables.OCISummaryPostData.lastSuccessRun = res.body.items[0].successfullRunTime;
      $variables.OCISummaryPostData.triggerType = "Detail";


      if (res.body.items[0].isOlderThan3Min === "Y") {
        const res2 = await Actions.callRest(context, {
          endpoint: 'essbiccdetail/postIcApiIntegrationV2FlowsRestProjectCOMMONKSY_XXI021_ESS_BICC_DTL1_0Essbiccdetail',
          body: JSON.stringify($variables.OCISummaryPostData),
        });
      }


      $application.variables.selectdaterange = value;
      let nextday = new Date();
      //nextday.setDate(nextday.getDate() + 1);
      nextday.setDate(nextday.getDate());
      const endToday = new Date(nextday.setHours(23, 59, 0, 0));
      let popup = document.getElementById("loading-dialog");

      let daycount = "0";
      let int_type;
      if (value === "1") {
        daycount = "0";
        const today = new Date();
        const startToday = new Date(today.setHours(0, 0, 0, 0));
        $application.variables.filterfromdate = this.toISOWithOffset(startToday);
        $application.variables.filtertodate = this.toISOWithOffset(endToday);
      } else if (value === "2") {
        daycount = "1";
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const today_1 = new Date();
         today_1.setDate(today_1.getDate() - 1);
        const endToday_1 = new Date(today_1.setHours(23, 59, 0, 0));
        const startYesterday = new Date(yesterday.setHours(0, 0, 0, 0));
        const endYesterday = new Date(yesterday.setHours(0, 0, 0, 0));
        $application.variables.filterfromdate = this.toISOWithOffset(startYesterday);
        $application.variables.filtertodate = this.toISOWithOffset(endToday_1);
      }
      else if (value === "3") {
        daycount = "6";
        const lastWeekStart = new Date();
        lastWeekStart.setDate(lastWeekStart.getDate() - 6);
        const startlastWeekStart = new Date(lastWeekStart.setHours(0, 0, 0, 0));
        const lastWeekEnd = new Date(lastWeekStart);
        lastWeekEnd.setDate(lastWeekEnd.getDate() + 6);
        $application.variables.filterfromdate = this.toISOWithOffset(startlastWeekStart);
        $application.variables.filtertodate = this.toISOWithOffset(endToday);

      }
      else if (value === "4") {
        daycount = "30";
        const lastMonthStart = new Date();
        lastMonthStart.setDate(lastMonthStart.getDate() - 30);
        const startlastMonthStart = new Date(lastMonthStart.setHours(0, 0, 0, 0));
        const lastMonthEnd = new Date(lastMonthStart.getFullYear(), lastMonthStart.getMonth() + 1, 0);
        $application.variables.filterfromdate = this.toISOWithOffset(startlastMonthStart);
        $application.variables.filtertodate = this.toISOWithOffset(endToday);
      }



      if ($application.currentPage.id === "oic-dashboard-start") {
        int_type = "OIC";
      } else if ($application.currentPage.id === "ess-dashboard-start") {
        int_type = "ESS";
      } else if ($application.currentPage.id === "bicc-dashboard-start") {
        int_type = "BICC";
      }

      if (!popup.isOpen()) {
        popup.open();
      }
      const essresult = await Actions.callRest(context, {
        endpoint: 'getSummaryServ/getDbGetSummary',
        uriParams: {
          'p_days_cnt': daycount,
          'p_job_type': int_type,
        },
      });
      if (essresult.ok) {
        popup.close();
      }

      let essres = essresult.body.items[0]['xxood_xxi021_job_summary_pkg.ess_summary_fnc(:1,:2)'];
      let getval = essres.split(":");
      let succount, cancount, errcount, waitcount, finishcount, warningcount, totalcount, inprogresscount;
      if ($application.currentPage.id === "ess-dashboard-start" || $application.currentPage.id === "bicc-dashboard-start") {
        succount = getval[1].split("-");
        cancount = getval[2].split("-");
        errcount = getval[3].split("-");
        waitcount = getval[4].split("-");
        finishcount = getval[5].split("-");
        warningcount = getval[6].split("-");
        $application.variables.getchartdata = [
          { "recordCount": cancount[1], "statusType": "Cancelled", "series": int_type },
          { "recordCount": errcount[1], "statusType": "Error", "series": int_type },
          { "recordCount": finishcount[1], "statusType": "Finished", "series": int_type },
          { "recordCount": succount[1], "statusType": "Success", "series": int_type },
          { "recordCount": waitcount[1], "statusType": "Wait", "series": int_type },
          { "recordCount": warningcount[1], "statusType": "Warning", "series": int_type }
        ];
      } else {

        totalcount = getval[0].split("-");
        succount = getval[1].split("-");
        errcount = getval[2].split("-");
        inprogresscount = getval[3].split("-");
        $application.variables.getchartdata = [
          { "recordCount": errcount[1], "statusType": "Error", "series": "OIC" },
          { "recordCount": succount[1], "statusType": "Success", "series": "OIC" },
          { "recordCount": inprogresscount[1], "statusType": "Inprogress", "series": "OIC" }
        ];
      }

      $application.variables.getsummarychart =
        new ArrayDataProvider($application.variables.getchartdata, { keyAttributes: 'statusType' });
      if ($application.currentPage.id === "ess-dashboard-start") {
        $application.variables.esserrorcount = errcount[1];
        $application.variables.esscancelledcount = cancount[1];
        $application.variables.esssuccesscount = succount[1];
        $application.variables.esswaitcount = waitcount[1];
        $application.variables.esswarning = warningcount[1];
        $application.variables.essfinishedcount = finishcount[1];
      } else if ($application.currentPage.id === "bicc-dashboard-start") {

        $application.variables.biccerrorcount = errcount[1];
        $application.variables.bicccancelledcount = cancount[1];
        $application.variables.biccsuccesscount = succount[1];
        $application.variables.biccwaitcount = waitcount[1];
        $application.variables.biccwarningcount = warningcount[1];
        $application.variables.biccfinishedcount = finishcount[1];
      } else if ($application.currentPage.id === "oic-dashboard-start") {

        $application.variables.ActiveIntegration = inprogresscount[1];
        $application.variables.Errorcount = errcount[1];
        $application.variables.success = succount[1];
        $application.variables.InstanceCount = totalcount[1];
      }
      if (essresult.ok) {
        popup.close();
      }




    }
  }

  return ComboValueChangeChain;
});