/* Copyright (c) 2024, Oracle and/or its affiliates */

define([], () => {
  'use strict';

  class PageModule {

    submenu() {
      let yourUl = document.getElementById('submenu-1');
      yourUl.classList.toggle("active");
      yourUl.classList.toggle("d-block");
      //yourUl.style.display = yourUl.style.display === 'none' ? 'block' : 'none';
    }
    submenu_one() {
      let yourUl = document.getElementById('submenu-2');
      yourUl.classList.toggle("active");
      yourUl.classList.toggle("d-block");
      // yourUl.style.display = yourUl.style.display === 'none' ? 'block' : 'none';
    }
    saasmenu_open() {
      let yourUl = document.getElementById('saas-submenu-1');
      yourUl.classList.toggle("active");
      yourUl.classList.toggle("d-block");
    }
    saassubmenu_open() {
      let yourUl = document.getElementById('saas-submenu-2');
      yourUl.classList.toggle("active");
      yourUl.classList.toggle("d-block");
    }
    saassubmenu1_open() {
      let yourUl = document.getElementById('saas-submenu-3');
      yourUl.classList.toggle("active");
      yourUl.classList.toggle("d-block");
    }
  }

  return PageModule;
});
