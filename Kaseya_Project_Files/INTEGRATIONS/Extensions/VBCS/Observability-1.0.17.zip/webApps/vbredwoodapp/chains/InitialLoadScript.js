define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class InitialLoadScript extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $application, $constants, $variables } = context;

      $variables.downloadbaseurl = 'https://kaseya-ibwgjb-test.fa.ocs.oraclecloud.com/';

      // ---- TODO: Add your code here ---- //
      let getusername = $application.user.fullName;
      let getname = getusername.split(" ");
      $variables.ProfileNameShort = getname[0].charAt(0) + getname[1].charAt(0);
      $variables.firstname = getname[0];
      function updateclock() {
        const date = new Date();
        const formatter = new Intl.DateTimeFormat('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        });

      }

      const date1 = new Date();
      const formatter = new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
      $variables.StaticCurrentDateTime = formatter.format(date1);
   //   const myInterval = setInterval(() => {
        const datetime = updateclock();
        $variables.currentdatetime = formatter.format(datetime);
      //  document.getElementsByClassName("datandtime")[0].innerHTML = formatter.format(datetime);
     // }, 1000);



      // $variables.currentdatetime = setInterval(updateclock(), 1000);

    }
  }

  return InitialLoadScript;
});
