define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class oiccount extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $application, $constants, $variables } = context;

     /* let response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_XxoodOicProcessCountV',
      });

      $variables.ocicount = response.body.items[0].instanceCount;*/
    }
  }

  return oiccount;
});
